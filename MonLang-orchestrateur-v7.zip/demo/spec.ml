app AtelierVelo

# Spécification générée par le dialogue guidé MonLang (déterministe, sans IA).
# Brief du projet : Une boutique d'accessoires vélo, réparation et pièces détachées.

entity Product
    name: String
    price: Money
    description: Text
    imageUrl: String
    category: String
    stock: Integer

entity Order
    total: Money
    status: String
    note: Text

entity Customer
    displayName: String

relation Customer hasMany Order

actor Admin
actor Customer

rule Product.name required
rule Order.total required
rule Customer.displayName required
rule Product.Read public
rule Order.Update ownedBy Customer
rule Order.Delete ownedBy Customer

workflow ManageProduct for Admin
    Create Product
    Read Product
    Update Product
    Delete Product

workflow ManageOrder for Customer
    Create Order
    Read Order
    Update Order
    Delete Order

workflow ManageCustomer for Customer
    Create Customer
    Read Customer
    Update Customer
    Delete Customer

workflow BrowseAdmin for Admin
    Read Order

workflow BrowseCustomer for Customer
    Read Product

seed Product
    name: "Théière Kyoto", price: 39.5, description: "Fonte émaillée, 0,8 L.", imageUrl: "https://picsum.photos/seed/shop1/800/600", category: "Théières", stock: 12
    name: "Tasse Duo", price: 18.0, description: "Grès artisanal, lot de deux.", imageUrl: "https://picsum.photos/seed/shop2/800/600", category: "Tasses", stock: 40
    name: "Thé vert Sencha", price: 12.5, description: "Récolte de printemps, 100 g.", imageUrl: "https://picsum.photos/seed/shop3/800/600", category: "Thés", stock: 87

landing
    brief: "Une boutique d'accessoires vélo, réparation et pièces détachées."
