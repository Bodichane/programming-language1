// AtelierVélo — frontend de démonstration, écrit par une IA contre le
// contrat MonLang (frontend_contract.json). Routes utilisées, TOUTES issues
// du contrat : GET /product (public, paginé), POST /register, POST /login,
// POST /order (JWT Customer), GET /order (JWT). Aucun script externe.
"use strict";

const API = "";                    // même origine : servi sur /site par monlang run
let token = null;                  // JWT (validité 1 h) — en mémoire seulement
let username = null;
let authMode = "login";            // ou "register"
let products = [];
let currentFilter = null;

const $ = (id) => document.getElementById(id);

async function api(method, path, body) {
  const headers = {};
  if (body) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = "Bearer " + token;
  const res = await fetch(API + path, {
    method, headers, body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch (_e) { /* corps non-JSON toléré */ }
  return { status: res.status, data };
}

// ---------- catalogue (public : aucune authentification requise) ----------
async function loadCatalogue() {
  const { status, data } = await api("GET", "/product?limit=50");
  if (status !== 200) {
    $("catalogue").textContent = "Catalogue indisponible (" + status + ").";
    return;
  }
  products = data.data;
  renderFilters();
  renderCatalogue();
}

function renderFilters() {
  const cats = [...new Set(products.map((p) => p.category).filter(Boolean))];
  const box = $("filters");
  box.innerHTML = "";
  if (!cats.length) return;
  const all = document.createElement("button");
  all.className = "ghost";
  all.textContent = "Tout";
  all.onclick = () => { currentFilter = null; renderCatalogue(); };
  box.appendChild(all);
  for (const cat of cats) {
    const b = document.createElement("button");
    b.className = "ghost";
    b.textContent = cat;
    b.onclick = () => { currentFilter = cat; renderCatalogue(); };
    box.appendChild(b);
  }
}

function renderCatalogue() {
  const grid = $("catalogue");
  grid.innerHTML = "";
  const list = currentFilter
    ? products.filter((p) => p.category === currentFilter) : products;
  for (const p of list) {
    const card = document.createElement("article");
    card.className = "card";
    const img = document.createElement("img");
    img.src = p.imageUrl || "";
    img.alt = p.name;
    const body = document.createElement("div");
    body.className = "body";
    const cat = document.createElement("div");
    cat.className = "cat";
    cat.textContent = p.category || "";
    const h3 = document.createElement("h3");
    h3.textContent = p.name;
    const desc = document.createElement("p");
    desc.className = "desc";
    desc.textContent = p.description || "";
    const foot = document.createElement("div");
    foot.className = "foot";
    const price = document.createElement("span");
    price.className = "price";
    price.textContent = Number(p.price).toFixed(2) + " €";
    const stock = document.createElement("span");
    stock.className = "stock" + (p.stock <= 15 ? " low" : "");
    stock.textContent = p.stock <= 15 ? "Stock limité : " + p.stock : "En stock : " + p.stock;
    const buy = document.createElement("button");
    buy.className = "primary";
    buy.textContent = "Commander";
    buy.onclick = () => order(p);
    foot.append(price, stock);
    body.append(cat, h3, desc, foot, buy);
    card.append(img, body);
    grid.appendChild(card);
  }
}

// ---------- authentification (register/login du contrat, acteur Customer) ----------
function openAuth() {
  $("auth-error").hidden = true;
  $("auth-dialog").showModal();
}

async function submitAuth(event) {
  event.preventDefault();
  const user = $("auth-user").value.trim();
  const pass = $("auth-pass").value;
  if (authMode === "register") {
    const r = await api("POST", "/register", { username: user, password: pass, actor: "Customer" });
    if (r.status !== 200) return showAuthError("Inscription refusée (" + r.status + ").");
  }
  const r = await api("POST", "/login", { username: user, password: pass });
  if (r.status !== 200 || !r.data.access_token) {
    return showAuthError("Identifiants refusés (" + r.status + ").");
  }
  token = r.data.access_token;
  username = user;
  $("auth-dialog").close();
  refreshNav();
  toast("Connecté en tant que " + username + ".");
}

function showAuthError(msg) {
  const e = $("auth-error");
  e.textContent = msg;
  e.hidden = false;
}

function refreshNav() {
  const connected = Boolean(token);
  $("nav-orders").hidden = !connected;
  $("nav-auth").textContent = connected ? "Se déconnecter" : "Se connecter";
  $("whoami").hidden = !connected;
  $("whoami").textContent = connected ? username : "";
}

// ---------- commandes (routes JWT du contrat) ----------
async function order(product) {
  if (!token) { openAuth(); return; }
  // Contrat v2 (monlang update) : Order gagne un champ 'note' (Text)
  const note = window.prompt("Une précision pour l'atelier ? (facultatif)", "") || "";
  const r = await api("POST", "/order", { total: product.price, status: "en attente", note });
  if (r.status === 200) toast("Commande enregistrée : " + product.name + ".");
  else toast("Commande refusée (" + r.status + ").");
}

async function showOrders() {
  const { status, data } = await api("GET", "/order?limit=50");
  const zone = $("orders");
  const list = $("orders-list");
  zone.hidden = false;
  list.innerHTML = "";
  if (status !== 200) { list.textContent = "Commandes indisponibles (" + status + ")."; return; }
  if (!data.data.length) { list.textContent = "Aucune commande pour l'instant."; return; }
  for (const o of data.data) {
    const row = document.createElement("div");
    row.className = "order";
    const label = document.createElement("span");
    label.textContent = "Commande n° " + o.id + " — " + Number(o.total).toFixed(2) + " €"
      + (o.note ? " — « " + o.note + " »" : "");
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = o.status;
    row.append(label, badge);
    list.appendChild(row);
  }
  zone.scrollIntoView({ behavior: "smooth" });
}

function toast(msg) {
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2600);
}

// ---------- branchements ----------
$("nav-auth").onclick = () => {
  if (token) { token = null; username = null; refreshNav(); toast("Déconnecté."); }
  else openAuth();
};
$("nav-orders").onclick = showOrders;
$("auth-form").addEventListener("submit", submitAuth);
$("auth-close").onclick = () => $("auth-dialog").close();
$("auth-switch").onclick = () => {
  authMode = authMode === "login" ? "register" : "login";
  $("auth-title").textContent = authMode === "login" ? "Se connecter" : "Créer un compte client";
  $("auth-submit").textContent = authMode === "login" ? "Connexion" : "Créer le compte";
  $("auth-switch").textContent = authMode === "login"
    ? "Pas de compte ? Créer un compte client" : "Déjà client ? Se connecter";
};

loadCatalogue();
