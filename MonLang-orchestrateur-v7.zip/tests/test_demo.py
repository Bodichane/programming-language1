# Verrou de la démonstration (docs/DEMO.md) : la spec livrée dans demo/ et
# le frontend livré dans demo/frontend/ doivent TOUJOURS former un ensemble
# qui compile et passe le smoke test comportemental. Si une évolution du
# compilateur, du contrat ou du smoke test casse la démo, ce test le dit —
# la démo ne peut pas pourrir en silence.
import os
import shutil
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cli import compile_project, check_coherence  # noqa: E402
from smoke_test import run_smoke_test  # noqa: E402

DEMO_DIR = os.path.join(os.path.dirname(__file__), "..", "demo")


def test_la_demo_livree_compile_et_passe_le_smoke_test(tmp_path):
    proj = tmp_path / "demo"
    proj.mkdir()
    shutil.copy2(os.path.join(DEMO_DIR, "spec.ml"), proj / "spec.ml")
    shutil.copytree(os.path.join(DEMO_DIR, "frontend"), proj / "frontend")

    compile_project(str(proj / "spec.ml"), str(proj))

    ok, errors, _w = check_coherence(str(proj))
    assert ok, errors
    ok, errors, warnings = run_smoke_test(str(proj), say=lambda *a: None)
    assert ok, errors
    # Le frontend a réellement parlé à l'API (pas un faux positif muet).
    assert not any("aucun appel API" in w for w in warnings), warnings


def test_le_frontend_de_la_demo_respecte_le_contrat_a_la_lettre():
    """Autonomie exigée par le contrat : aucun script externe dans la démo."""
    frontend = os.path.join(DEMO_DIR, "frontend")
    for name in os.listdir(frontend):
        with open(os.path.join(frontend, name), encoding="utf-8") as fh:
            content = fh.read()
        assert "https://cdn" not in content and "<script src=\"http" not in content
