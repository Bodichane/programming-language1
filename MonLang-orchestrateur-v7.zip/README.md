# MonLang — Plateforme d'orchestration logicielle

Le constat : une seule IA ne peut pas toujours produire des applications
complexes de manière cohérente. MonLang ne cherche donc plus à tout
générer — il ORCHESTRE : un dialogue guidé (sans IA) transforme votre idée
en spécification DSL fiable et déterministe ; MonLang en dérive le backend
complet (base de données, API, règles métier, authentification) ET un
contrat frontend ; une IA spécialisée (Claude, GPT…) construit l'interface
sur ce contrat ; MonLang vérifie la cohérence de l'ensemble et le fait
évoluer sans jamais la casser. Le DSL reste la source de vérité.

## Voir d'abord : la démonstration complète

`docs/DEMO.md` déroule un projet réel de bout en bout, sorties authentiques
à l'appui : boutique créée en 8 réponses, frontend écrit par une IA contre
le contrat, utilisation, puis évolution de la spec avec données préservées.
Le projet est livré dans `demo/` et un test garantit qu'il compile et passe
le smoke test à chaque CI.

## Le cycle de vie complet

```bash
monlang                  # dialogue guidé → spec.ml → backend + contrat frontend
#   → donner FRONTEND_PROMPT.md à une IA UI, qui écrit dans frontend/
monlang run MonProjet    # vérifie la cohérence (spec ↔ backend ↔ contrat ↔
                         # frontend) puis lance l'application (frontend sur /site)
monlang update MonProjet # après évolution de la spec : recompile, régénère le
                         # contrat, rapporte le delta à transmettre à l'IA
                         # frontend — la base de données est préservée
monlang compile spec.ml  # compiler directement une spec existante
```

**Sans clé API (abonnement Claude)** — deux voies :

*Avec Claude Code (recommandé — l'agent travaille directement dans le
dossier, authentification par abonnement via `claude login`) :*

```bash
monlang                              # → CLAUDE.md + FRONTEND_PROMPT.md dans le projet
cd MonProjet && claude               # interactif : "construis le frontend"
#   ou, sans interaction :
monlang frontend MonProjet --provider claude-code
monlang run MonProjet
```

Le `CLAUDE.md` généré dans le projet cadre la session (le frontend, rien
d'autre ; artefacts backend interdits — leur intégrité est de toute façon
vérifiée par empreinte après chaque exécution headless) et donne à l'agent
la commande pour vérifier lui-même son travail (`monlang run . --check`).

*Avec une conversation claude.ai (copier/coller) :*

```bash
#   1. coller FRONTEND_PROMPT.md dans la conversation
#   2. télécharger le résultat (ZIP ou index.html autonome)
monlang import ~/Téléchargements/mon-app.zip MonProjet
monlang run MonProjet
```

Avec une clé (`ANTHROPIC_API_KEY`), `monlang frontend MonProjet` appelle
l'API directement. Les trois voies partagent la même re-vérification
(cohérence + smoke test) et la même boucle de correction.

Le dialogue de `monlang` repose sur un moteur à RÈGLES, sans modèle d'IA :
il ouvre sur un catalogue des 10 applications les plus construites par les
devs web (portfolio, blog, boutique, tâches, forum, annonces, réservation,
inventaire, dépenses, classement — point 45) ; choisir un modèle pré-remplit
tout avec des données de démonstration réalistes et ne pose que les
questions de suivi du modèle (« suivre le stock ? », « permettre les
commentaires ? »). « Partir de zéro » donne le dialogue libre complet.
Dans les deux cas : réponses validées, spec revalidée par le vrai parseur
avant d'être écrite, et réponses en français libre possibles avec un modèle
local (`--nl`, point 44). Détail du pivot : points 40 à 45 de
`docs/design_decisions.md`.

Installation du lanceur : `ln -s $(pwd)/monlang ~/.local/bin/monlang`
(ou appeler `./monlang` depuis la racine du dépôt).

## Sous le capot : le compilateur d'intention logicielle

Transformer une spécification textuelle structurée en une application
complète générée automatiquement, sans écrire de code technique.

## STATUT DU PROJET

| Phase | Objectif | Statut |
| :--- | :--- | :--- |
| **0 — Cadrage** | Vision, Problème & Objectifs | 🟢 Validé |
| **1 — Modèle conceptuel** | Définition des 6 concepts piliers | 🟢 Validé |
| **2 — DSL** | Syntaxe officielle & 5 Apps de validation | 🟢 Validé |
| **3 — Parser** | Traduction DSL → JSON | 🟢 Validé |
| **4 — AST** | Modèle intermédiaire & Validation cohérence | 🟢 Validé |
| **5 — Génération** | Production DB, API & App fonctionnelle | 🟢 Validé |
| **6 — Boucle complète** | Modification DSL → Changement automatique de l'app | 🟢 Validé |
| **7 — IA** | Traduction Langage Naturel → DSL MonLang | 🟢 Validé |

Le tableau ci-dessus couvre les 7 phases fondatrices. Le développement se
poursuit depuis en « briques » de capacités (`hidden`, `increments`,
`decrements`, `categorized`, `generated`...) — voir les points 24 à 30 de
`docs/design_decisions.md`.

## Installation et premier essai

```bash
pip install -r requirements.txt
python3 src/main.py exemples/01_portfolio.ml   # compile un exemple
python3 -m uvicorn app:app                          # lance l'app générée
```

Les specs utilisent l'extension `.ml` (l'ancienne extension `.yaml`,
trompeuse — ce n'est pas du YAML — reste acceptée par le compilateur pour
d'éventuels fichiers existants). Par défaut les artefacts (`app.py`,
`schema.sql`, `sandbox_ai.py`, `.jwt_secret`...) sont écrits à la racine du
dépôt ; l'option `--output DIR` permet de compiler chaque projet dans son
propre dossier sans écraser le précédent (lancer alors le serveur depuis ce
dossier : `cd DIR && python3 -m uvicorn app:app`).

## Faire évoluer une application (migrations)

Ajouter un champ à une entité puis recompiler **dans le même dossier**
(en conservant `app.db`) applique automatiquement la migration au
démarrage : les nouvelles colonnes sont ajoutées par `ALTER TABLE ADD
COLUMN`, sans toucher aux données existantes (elles reçoivent `NULL`). Les
suppressions de colonnes, changements de type et renommages ne sont PAS
automatisés car potentiellement destructifs — détail et raisons dans
`docs/MIGRATIONS.md`. Pour repartir de zéro, supprimer `app.db` avant de
redémarrer.

## Données de démonstration (sites déjà remplis)

Un bloc `seed` dans la spec pré-remplit la base au démarrage (si vide), pour
qu'un site s'ouvre déjà peuplé — avec de vraies images via des URLs publiques
(picsum.photos). L'insertion est idempotente et n'écrase jamais de données
réelles. Les 5 exemples fournis en contiennent : l'IA frontend
trouve une API déjà peuplée, sans aucune création manuelle.
Détails et syntaxe : `docs/SEED.md`.

```bash
python3 src/main.py exemples/02_boutique.ml --output build/shop
cd build/shop && python3 -m uvicorn app:app
# GET http://127.0.0.1:8000/product : le catalogue est déjà là
```

## Déploiement multi-workers

Les applications générées sont sans état en mémoire partagée : la
révocation de jetons et la limitation de débit (5 tentatives / 60 s / IP sur
`/register` et `/login`) sont persistées en base, donc partagées entre
workers. On peut lancer `python3 -m uvicorn app:app --workers N` sans que le
quota de débit ne se multiplie par worker. Voir les points 33 (rate
limiting) et 7 (révocation) de `docs/design_decisions.md`.

## Authentification

Chaque application générée possède un vrai registre d'utilisateurs (table
`_monlang_users`, mot de passe haché — voir `docs/design_decisions.md`
point 7) :
1. `POST /register` avec `{"username", "password", "actor"}` pour créer un
   compte (mot de passe : 8 caractères minimum)
2. `POST /login` avec `{"username", "password"}` pour obtenir un token JWT
3. `POST /logout` (avec le token en en-tête `Authorization`) pour le révoquer
   avant son expiration naturelle
4. Le rôle (`actor`) et l'identifiant (`user_id`) portés par le token
   viennent du compte réel, pas d'une déclaration libre du client

`/login` et `/register` sont protégées par une limitation de débit (5
tentatives / 60 secondes / IP, par route).

**Secret JWT :** un secret aléatoire unique est généré à la première
compilation d'un projet et stocké dans `.jwt_secret` (ignoré
via `.gitignore` — ne jamais le committer). Recompiler la spec ne le
régénère pas ; le supprimer manuellement force le renouvellement (invalide
alors toutes les sessions actives).

## Contrôle d'accès par enregistrement

- **`rule Entite.Action ownedBy Acteur`** : seul le propriétaire (colonne de
  relation auto-peuplée à la création) peut exécuter l'action — voir le
  point 5 de `docs/design_decisions.md`.
- **`rule Entite.Action accessibleBy col1, col2`** : généralisation à deux
  parties ou plus — l'action n'est permise que si l'appelant est l'une des
  « parties » de l'enregistrement (colonnes contenant un identifiant
  d'utilisateur). Cas d'usage canonique : la messagerie privée, où
  expéditeur et destinataire accèdent au même message et personne d'autre,
  liste filtrée comprise. Voir `exemples/19_private_messages.ml` et le
  point 31 de `docs/design_decisions.md`.

## Contenu public sans compte, et identité visuelle personnalisée

Deux ajouts pour des cas d'usage comme un portfolio (contenu public + zone
d'administration) :

- **`rule Entite.Action public`** retire l'obligation d'authentification
  d'une action précise (ex. `rule Project.Read public` pour un portfolio
  lisible sans compte, `rule Message.Create public` pour un formulaire de
  contact ouvert). Voir `docs/design_decisions.md` point 16.
- **`ui NomEntite / theme: ...`** permet de forcer explicitement l'identité
  visuelle (palette/typographie) transmise comme direction de design à l'IA
  frontend via le contrat, plutôt que de la laisser se déduire du domaine.
  Voir `docs/design_decisions.md` points 17, 20 et 41.

Exemple complet : `exemples/01_portfolio.ml`.

## Frontend : contrat + IA spécialisée (plus aucun front généré)

Depuis le pivot (point 41 de `docs/design_decisions.md`), MonLang ne génère
plus AUCUN frontend — ni landing, ni tableau de bord, ni archétypes. Chaque
compilation produit à la place :

- **`frontend_contract.json`** : description machine-lisible et exhaustive
  de ce que le backend expose (routes, auth, champs et leurs règles
  `hidden`/`generated`/`categorized`, pagination), dérivée des mêmes
  structures que la génération des routes — un test de la CI vérifie qu'elle
  ne peut pas diverger de `app.py`.
- **`FRONTEND_PROMPT.md`** : brief prêt à donner à une IA d'interface
  (Claude, GPT…), incluant le brief produit (bloc `landing / brief:` de la
  spec, seul vestige conservé de l'ancien bloc `landing`) et une direction
  de design déterministe propre au projet (palette, typographies — stable
  via `.monlang_theme_seed`, voir point 20).

L'IA écrit son résultat dans `frontend/` (`index.html` en point d'entrée) ;
`monlang run` le sert sur `/site` via un wrapper `serve.py`, sans jamais
modifier `app.py`. Deux façons d'y arriver :

- **`monlang frontend`** (clé dans `ANTHROPIC_API_KEY`) : appel API direct,
  re-vérification automatique, une tentative de correction.
- **`monlang import <zip|html|dossier> <projet>`** (sans clé — abonnement
  claude.ai) : coller le brief dans la conversation, télécharger le
  résultat, l'importer. Mêmes garde-fous (zip-slip, extensions en liste
  blanche, frontend autonome sans CDN), même re-vérification ; le frontend
  précédent est conservé dans `frontend.precedent/`. En cas d'échec, les
  erreurs affichées se recollent telles quelles dans la conversation pour
  correction. Voir point 42 de `docs/design_decisions.md`.

Avant tout lancement, `monlang run` exécute un **smoke test comportemental**
sur un serveur éphémère (base neuve, données réelles intouchées) : chaque
route du contrat est éprouvée en HTTP réel (publiques → 200, protégées →
refus sans jeton, compte réel créé pour vérifier l'accès avec jeton), et si
Node.js est disponible, `frontend/index.html` est exécuté dans jsdom contre
ce serveur — toute exception JavaScript ou tout appel hors contrat bloque le
lancement (`--skip-smoke` pour contourner en connaissance de cause).

## Structure du Dépôt
- `docs/` : Notes théoriques et spécifications des phases de cadrage.
  Voir en particulier `docs/design_decisions.md` pour le détail des règles
  strictes du compilateur (collisions de privilèges, restrictions de champ,
  contrôle par propriété, garde-fou IA) et comment les contourner
  légitimement quand c'est prévu.
- `exemples/` : Applications écrites en syntaxe officielle `.ml`.
- `src/` : Code source du compilateur et de l'orchestrateur (Parser, AST,
  Générateur backend, contrat frontend, dialogue guidé, CLI, smoke test,
  boucle IA frontend, Sandbox IA des fonctions `custom`, Traducteur langage
  naturel).
- `tests/` : `test_exploit.py` (audit offensif sur l'exemple Todo),
  `test_exploit_all.py` (même audit généralisé à tous les exemples),
  `test_compile_all.py` (test pytest de non-régression sur tous les exemples).
- `requirements.txt` : dépendances du compilateur et des apps générées.
- `.github/workflows/ci.yml` : intégration continue (compile tous les
  exemples + rejoue l'audit offensif, via la suite pytest, à chaque
  push/pull request).

## Utiliser l'application générée

- **`/docs`** : la documentation Swagger interactive fournie gratuitement par
  FastAPI — toujours disponible, pour explorer et tester chaque route.
- **`/`** : redirige vers `/docs`.
- **`/site`** : l'interface produite par l'IA frontend, quand `frontend/`
  existe et que l'application est lancée par `monlang run`.

## Répondre au dialogue en langage naturel (modèle local)

`monlang init --nl` active la compréhension des réponses libres : un modèle
local (Ollama, aucune donnée ne quitte la machine) mappe « c'est l'admin qui
s'en occupe » vers le choix fermé attendu. Le modèle n'écrit JAMAIS de DSL —
il interprète, sa proposition est affichée (« ↳ compris comme : 'Admin' »)
et revalidée par les mêmes règles que la saisie stricte ; si Ollama tombe,
le dialogue continue en saisie stricte. Voir point 44 de
`docs/design_decisions.md` pour la répartition des rôles (et pourquoi c'est
plus robuste que la traduction intégrale ci-dessous).

## Générer une application depuis une description en langage naturel

En plus d'écrire directement un fichier `.ml`, il est possible de décrire
l'application en français et de laisser un modèle IA local produire la
spécification MonLang correspondante (celle-ci est ensuite validée par le
vrai parseur avant compilation — si elle ne compile pas, une correction est
retentée automatiquement une fois) :
```bash
monlang init --prompt "une todo-list simple avec des utilisateurs"
# (l'ancien 'python3 src/main.py --prompt' fonctionne toujours, mais ne
#  produit que le backend — la commande ci-dessus produit aussi le contrat
#  frontend, le CLAUDE.md de projet et l'état 'monlang.json')
```
Voie assumée comme plus fragile que le dialogue (`--nl`) : le modèle rédige
tout le DSL d'un bloc — validé par le parseur, une correction automatique.
Nécessite un serveur Ollama local (voir section suivante).

## Configurer le modèle IA local (échappatoire des blocs `custom` et `--prompt`)

Le remplissage automatique des blocs `custom` (`sandbox_ai.py`) et la
traduction langage naturel → spec (`--prompt`) s'appuient tous les deux sur
un serveur [Ollama](https://ollama.com) tournant en local, à l'adresse
`http://localhost:11434`. Aucun modèle n'est fourni dans ce dépôt (les
fichiers de modèle pèsent plusieurs gigaoctets) — le choix du modèle est
laissé à l'utilisateur, selon la puissance de sa machine :

1. Installer Ollama : voir https://ollama.com/download
2. Télécharger un modèle adapté à du code, par exemple :
   - `ollama pull qwen2.5-coder:3b` — léger, adapté à un ordinateur portable
     sans GPU dédié (c'est le modèle utilisé par défaut)
   - `ollama pull qwen2.5-coder:7b` ou plus — meilleure qualité de code
     généré, nécessite davantage de RAM/VRAM
3. Si un autre modèle est utilisé, adapter la valeur `"model"` dans
   `generate_custom_logic_with_ai()` (`src/ai_sandbox_filler.py`), ou passer
   `--model nom-du-modele` pour la commande `--prompt`.

**Si aucun serveur Ollama n'est disponible**, la compilation d'un fichier
`.ml` existant aboutit quand même : le socle déterministe (schéma DB,
routes API, contrôle d'accès) est généré normalement, et chaque bloc
`custom` reste disponible sous forme de coquille vide sécurisée à compléter
manuellement dans `sandbox_ai.py`. (L'option `--prompt`, elle, nécessite
évidemment Ollama puisqu'elle sert justement à produire la spec de départ.)

## Intégration continue

`.github/workflows/ci.yml` compile automatiquement tous les exemples de
`exemples/` et rejoue l'audit offensif (`tests/test_exploit_all.py`) contre
chacun à chaque push/pull request, pour détecter une régression avant
qu'elle ne s'accumule sur plusieurs versions.
