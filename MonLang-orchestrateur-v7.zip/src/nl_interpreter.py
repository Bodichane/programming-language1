# ─────────────────────────────────────────────────────────────────────
# INTERPRÈTE LOCAL DES RÉPONSES — point 44 du journal. Le "petit modèle
# qui comprend l'utilisateur" annoncé dès le pivot, mais avec la bonne
# répartition des rôles :
#
#   LE MODÈLE N'ÉCRIT JAMAIS DE DSL. Il ne fait qu'INTERPRÉTER : mapper
#   une réponse libre ("c'est l'admin qui s'en occupe", "oui bien sûr",
#   "appelle-la Projet") vers la réponse fermée que le dialogue attend
#   ("1", "o", "Projet"). L'émission de la spec reste 100 % déterministe,
#   et chaque réponse mappée repasse par les MÊMES validateurs que la
#   saisie stricte : un mauvais mapping est simplement redemandé, jamais
#   accepté en silence.
#
# Pourquoi cette architecture plutôt que la traduction intégrale (phase 7,
# --prompt) : un modèle local de 3B n'a jamais vu MonLang à l'entraînement
# — lui demander de rédiger un DSL inventé est fragile (c'est mesuré : la
# phase 7 a besoin d'une boucle de correction et échoue encore parfois).
# Le mapper vers un choix fermé est une tâche de classification, à la
# portée d'un petit modèle, et l'erreur y est inoffensive par construction.
#
# Le modèle tourne en LOCAL via Ollama (http://localhost:11434), comme la
# phase 7 et les blocs 'custom' — aucune donnée ne quitte la machine.
# S'il est indisponible (au départ ou en cours de dialogue), le dialogue
# continue en saisie stricte : jamais bloquant, jamais silencieux.
# ─────────────────────────────────────────────────────────────────────
import json

import requests

OLLAMA_GENERATE_URL = "http://localhost:11434/api/chat"
OLLAMA_PING_URL = "http://localhost:11434/api/tags"
DEFAULT_NL_MODEL = "qwen2.5-coder:3b"

SYSTEM_PROMPT = """Tu assistes un questionnaire de spécification logicielle.
On te donne la question posée, son type, et la réponse LIBRE de
l'utilisateur. Ton unique rôle : convertir cette réponse libre vers le
format strict attendu. Tu ne décides jamais à la place de l'utilisateur —
tu reformules sa réponse, c'est tout.

Formats selon le type :
- "choice"    : réponds par le NUMÉRO de l'option choisie (ex. "2"),
                ou "0" si l'utilisateur ne veut aucune option (quand
                "0 = aucun" figure dans les options).
- "yes_no"    : réponds "o" ou "n".
- "identifier": réponds par un identifiant CamelCase valide (lettres et
                chiffres, commence par une lettre) dérivé de la réponse —
                ex. "les messages des clients" -> "Message". Réponds ""
                (vide) si l'utilisateur signifie qu'il a terminé / rien à
                ajouter.
- "free_text" : réponds par le texte, nettoyé des guillemets doubles.

CONSIGNE CRUCIALE : réponds au format JSON avec une seule clé "answer".
Si la réponse de l'utilisateur est ambiguë ou sans rapport avec la
question, réponds {"answer": null}."""


class InterpreterUnavailable(Exception):
    """Ollama injoignable — le dialogue doit continuer en saisie stricte."""


def is_ollama_available(timeout=1.5):
    try:
        return requests.get(OLLAMA_PING_URL, timeout=timeout).status_code == 200
    except requests.exceptions.RequestException:
        return False


class OllamaInterpreter:
    """Callable (question, kind, options, réponse libre) -> réponse stricte
    ou None. Toute panne réseau lève InterpreterUnavailable : c'est le
    dialogue qui décide de continuer sans interprète (il le fait toujours)."""

    def __init__(self, model=DEFAULT_NL_MODEL, timeout=30):
        self.model = model
        self.timeout = timeout

    def __call__(self, question, kind, options, raw_answer):
        options_block = ""
        if options:
            options_block = "Options :\n" + "\n".join(
                f"  {i + 1}. {opt}" for i, opt in enumerate(options))
        user_msg = (f"Question ({kind}) : {question}\n{options_block}\n"
                    f"Réponse libre de l'utilisateur : {raw_answer!r}")
        try:
            resp = requests.post(OLLAMA_GENERATE_URL, json={
                "model": self.model,
                "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                             {"role": "user", "content": user_msg}],
                "stream": False,
                "format": "json",
                "options": {"temperature": 0},
            }, timeout=self.timeout)
            resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise InterpreterUnavailable(str(e))
        try:
            answer = json.loads(resp.json()["message"]["content"]).get("answer")
        except (KeyError, ValueError, json.JSONDecodeError):
            return None  # sortie illisible = pas d'interprétation, on redemande
        if answer is None:
            return None
        return str(answer).strip()
