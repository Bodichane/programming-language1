# ─────────────────────────────────────────────────────────────────────
# MOTEUR DE DIALOGUE GUIDÉ — pivot "MonLang orchestrateur" (brique 1).
#
# Objectif : remplacer l'écriture manuelle d'une spec .ml par une
# conversation guidée par RÈGLES (aucun modèle d'IA). Les questions sont
# fermées autant que possible, chaque réponse est validée, et la spec
# produite est TOUJOURS revalidée par le vrai parseur + l'audit AST avant
# d'être rendue — même garantie de déterminisme que le compilateur.
#
# Décision de conception : le moteur ne reçoit JAMAIS stdin directement.
# Il consomme une fonction ask(prompt) -> str, ce qui permet :
#   - en usage réel : ask = input (voir cli.py)
#   - en test : ask = itérateur de réponses scriptées (exécution réelle,
#     conformément à la méthode de travail du projet — pas de mock du
#     pipeline, la spec produite est réellement compilée dans les tests).
#
# Couvert depuis le point 41 : ownedBy (propriété par enregistrement, avec
# création automatique de l'entité propriétaire et de sa relation) et
# sharedBy (gestion partagée entre plusieurs acteurs). Hors de portée
# assumé : accessibleBy (accès à deux parties) et blocs custom
# (échappatoire IA) — briques suivantes.
# ─────────────────────────────────────────────────────────────────────
import re

IDENT_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]*$")

# Types proposés dans le menu — sous-ensemble sûr des types de la grammaire
# (Date/UUID exclus du menu v1 : peu utiles sans widget de saisie dédié).
FIELD_TYPES = ["String", "Text", "Integer", "Float", "Money", "Boolean", "Email", "DateTime"]

# Types qu'on sait seeder de façon déterministe (la grammaire 'seed' n'accepte
# que STRING_LITERAL et SIGNED_NUMBER — pas de booléen ni de date).
SEEDABLE_TYPES = {"String", "Text", "Integer", "Float", "Money", "Email"}

RELATION_TYPES = ["hasMany", "hasOne", "belongsTo"]


class DialogueError(Exception):
    """Réponse invalide répétée ou incohérence — le moteur ne devine jamais."""


class GuidedDialogue:
    def __init__(self, ask, say=None, max_retries=3, interpreter=None):
        """'interpreter' (optionnel) : le point de greffe du modèle local
        annoncé dès le pivot (point 44). Callable
        (question, kind, options, réponse libre) -> réponse stricte ou None.
        Il n'intervient QU'APRÈS un échec de la validation stricte, et sa
        proposition repasse par le MÊME validateur — le déterminisme de
        l'émission n'est jamais entamé. S'il lève InterpreterUnavailable
        (Ollama tombé en cours de route), il est débranché et le dialogue
        continue en saisie stricte, avec un message explicite."""
        self._ask_fn = ask
        self._say = say or (lambda *_: None)
        self.max_retries = max_retries
        self._interpreter = interpreter

    # ---------- primitives de question (chacune valide et redemande) ----------
    def _ask(self, prompt, validate, error_msg, kind="free_text", options=None):
        for _ in range(self.max_retries):
            answer = self._ask_fn(prompt).strip()
            ok, value = validate(answer)
            if ok:
                return value
            # Réponse libre ? L'interprète local tente un mapping vers le
            # format strict — sa proposition est validée comme n'importe
            # quelle saisie, et montrée à l'utilisateur (jamais silencieux).
            if self._interpreter is not None:
                mapped = self._try_interpret(prompt, kind, options, answer)
                if mapped is not None:
                    ok, value = validate(mapped)
                    if ok:
                        self._say(f"  ↳ compris comme : {mapped!r}")
                        return value
            self._say(f"  ✗ {error_msg}")
        raise DialogueError(f"Réponse invalide après {self.max_retries} tentatives : {prompt!r}")

    def _try_interpret(self, prompt, kind, options, raw_answer):
        from nl_interpreter import InterpreterUnavailable
        try:
            return self._interpreter(prompt, kind, options, raw_answer)
        except InterpreterUnavailable:
            self._say("  ⚠️  Modèle local injoignable — poursuite en saisie "
                      "stricte (numéros, o/n, identifiants).")
            self._interpreter = None
            return None

    def _ask_identifier(self, prompt, forbidden=()):
        def validate(a):
            if IDENT_RE.match(a) and a not in forbidden:
                return True, a
            return False, None
        return self._ask(prompt, validate,
                         "Identifiant attendu (lettres/chiffres, commence par une lettre, sans doublon).",
                         kind="identifier")

    def _ask_optional_identifier(self, prompt, forbidden=()):
        """Comme _ask_identifier mais une réponse vide signifie 'terminé'."""
        def validate(a):
            if a == "":
                return True, None
            if IDENT_RE.match(a) and a not in forbidden:
                return True, a
            return False, None
        return self._ask(prompt, validate,
                         "Identifiant attendu (ou vide pour terminer), sans doublon.",
                         kind="identifier")

    def _ask_choice(self, prompt, options, allow_none=False):
        menu = "  ".join(f"[{i + 1}] {opt}" for i, opt in enumerate(options))
        none_hint = "  [0] aucun" if allow_none else ""
        full = f"{prompt}\n  {menu}{none_hint}\n> "

        def validate(a):
            if allow_none and a == "0":
                return True, None
            if a.isdigit() and 1 <= int(a) <= len(options):
                return True, options[int(a) - 1]
            return False, None
        return self._ask(full, validate, "Choisir un numéro du menu.",
                         kind="choice", options=list(options) + (["aucun"] if allow_none else []))

    def _ask_yes_no(self, prompt):
        def validate(a):
            low = a.lower()
            if low in ("o", "oui", "y", "yes"):
                return True, True
            if low in ("n", "non", "no"):
                return True, False
            return False, None
        return self._ask(f"{prompt} (o/n) > ", validate, "Répondre o ou n.", kind="yes_no")

    def _ask_free_text(self, prompt):
        def validate(a):
            # Les guillemets doubles casseraient le STRING_LITERAL émis.
            if a and '"' not in a and "\n" not in a:
                return True, a
            return False, None
        return self._ask(prompt, validate, "Texte non vide, sans guillemets doubles.",
                         kind="free_text")

    # ---------- déroulé du dialogue ----------
    def run(self):
        """Mène la conversation complète et retourne le texte de la spec .ml.
        REFONTE (point 45) : le dialogue ouvre sur le catalogue des 10 types
        d'applications les plus construits par les devs web — choisir un
        modèle pré-remplit tout et ne pose que les questions de suivi
        propres au modèle. « Partir de zéro » conserve le dialogue libre."""
        from app_templates import TEMPLATES, FREE_MODE_LABEL
        self._say("\n─── MonLang : décrivons votre projet (aucune IA, questions guidées) ───\n")
        labels = [f"{t['name']} — {t['hint']}" for t in TEMPLATES] + [FREE_MODE_LABEL]
        picked = self._ask_choice("Quel type d'application construisez-vous ?", labels)
        if picked == FREE_MODE_LABEL:
            return self._run_free()
        template = TEMPLATES[labels.index(picked)]
        return self._run_from_template(template)

    def _run_from_template(self, template):
        """Chemin « modèle » : questions de suivi spécifiques, puis les
        finitions communes. Le modèle est copié en profondeur — le catalogue
        n'est jamais muté entre deux exécutions (déterminisme)."""
        import copy
        from app_templates import apply_effects
        template = copy.deepcopy(template)

        app_name = self._ask_identifier("Nom de l'application (ex. StudioNova) > ")
        description = self._ask_free_text(
            "Décrivez le projet en une phrase (servira de brief frontend) > ")

        for followup in template["followups"]:
            if self._ask_yes_no(followup["ask"]):
                apply_effects(template, followup["effects"])

        # Conversion du modèle vers le format de l'émetteur
        entities = {name: list(meta["fields"]) for name, meta in template["entities"].items()}
        actors = list(template["actors"])
        managers = {name: [meta["manager"]] for name, meta in template["entities"].items()}
        readers = {name: set(meta["readers"]) for name, meta in template["entities"].items()}
        public_read = [n for n, m in template["entities"].items() if m["public_read"]]
        public_create = [n for n, m in template["entities"].items() if m["public_create"]]
        owned = {n: m["manager"] for n, m in template["entities"].items() if m["owned"]}
        relations = list(template["relations"])

        # Échappatoire : une entité personnalisée en plus du modèle.
        while self._ask_yes_no("Ajouter une entité personnalisée en plus du modèle ?"):
            name = self._ask_identifier("  Nom de l'entité > ", forbidden=entities.keys())
            fields = []
            while True:
                taken = [f for f, _ in fields]
                fprompt = (f"  Premier champ de {name} > " if not fields
                           else f"  Autre champ de {name} (vide pour terminer) > ")
                fname = (self._ask_identifier(fprompt, forbidden=taken) if not fields
                         else self._ask_optional_identifier(fprompt, forbidden=taken))
                if fname is None:
                    break
                ftype = self._ask_choice(f"  Type de {name}.{fname} ?", FIELD_TYPES)
                fields.append((fname, ftype))
            entities[name] = fields
            managers[name] = [actors[0] if len(actors) == 1
                              else self._ask_choice(f"  Qui gère {name} en écriture ?", actors)]
            readers[name] = set()
            if self._ask_yes_no(f"  {name} doit-elle être lisible sans compte ?"):
                public_read.append(name)

        self._ensure_ownership_structure(entities, managers, readers, owned, relations)

        want_seed = bool(template["seeds"]) and self._ask_yes_no(
            "Pré-remplir le site avec les données de démonstration du modèle ?")
        want_landing = self._ask_yes_no(
            "Transmettre votre description à l'IA frontend comme brief de page d'accueil ?")

        spec = self._emit_spec(app_name, description, entities, relations, actors,
                               managers, readers, public_read, public_create,
                               owned, want_seed, want_landing,
                               extra_rules=template["extra_rules"],
                               custom_seeds=template["seeds"])
        from parser import parse_monlang_string
        from ast_validator import MonLangAST
        MonLangAST(parse_monlang_string(spec)).validate_and_audit()
        return spec

    @staticmethod
    def _ensure_ownership_structure(entities, managers, readers, owned, relations):
        """Toute règle ownedBy exige une entité propriétaire homonyme de
        l'acteur + la relation qui fournit la clé étrangère (point 5, motif
        de exemples/03). Créées ici si absentes — partagé entre le chemin
        « modèle » et le chemin libre."""
        for ent, owner in list(owned.items()):
            if owner not in entities:
                entities[owner] = [("displayName", "String")]
                managers[owner] = [owner]
                readers[owner] = set()
            if (owner, "hasMany", ent) not in relations:
                relations.append((owner, "hasMany", ent))

    def _run_free(self):
        """Le dialogue libre historique — inchangé, derrière « partir de zéro »."""
        app_name = self._ask_identifier("Nom de l'application (ex. StudioNova) > ")
        description = self._ask_free_text("Décrivez le projet en une phrase (servira à la page d'accueil) > ")

        # Entités et champs
        entities = {}   # name -> [(field, type)]
        self._say("\nDéfinissons les données (entités). Exemple : Project, Message, Article…")
        while True:
            prompt = ("Nom de la 1ère entité > " if not entities
                      else "Nom d'une autre entité (vide pour terminer) > ")
            name = (self._ask_identifier(prompt, forbidden=entities.keys()) if not entities
                    else self._ask_optional_identifier(prompt, forbidden=entities.keys()))
            if name is None:
                break
            fields = []
            while True:
                taken = [f for f, _ in fields]
                fprompt = (f"  Premier champ de {name} > " if not fields
                           else f"  Autre champ de {name} (vide pour terminer) > ")
                fname = (self._ask_identifier(fprompt, forbidden=taken) if not fields
                         else self._ask_optional_identifier(fprompt, forbidden=taken))
                if fname is None:
                    break
                ftype = self._ask_choice(f"  Type de {name}.{fname} ?", FIELD_TYPES)
                fields.append((fname, ftype))
            entities[name] = fields

        entity_names = list(entities.keys())

        # Vitrine publique (lecture sans compte) et création publique (contact)
        public_read = []
        for ent in entity_names:
            if self._ask_yes_no(f"L'entité {ent} doit-elle être LISIBLE sans compte (vitrine publique) ?"):
                public_read.append(ent)
        public_create = self._ask_choice(
            "Une entité peut-elle être CRÉÉE sans compte (ex. formulaire de contact) ?",
            entity_names, allow_none=True)

        # Acteurs
        actors = []
        self._say("\nQui utilise l'application ? (ex. Admin, Visitor, Member…)")
        while True:
            prompt = ("Nom du 1er acteur > " if not actors
                      else "Autre acteur (vide pour terminer) > ")
            a = (self._ask_identifier(prompt, forbidden=actors) if not actors
                 else self._ask_optional_identifier(prompt, forbidden=actors))
            if a is None:
                break
            actors.append(a)

        # Gestion en écriture : un acteur unique par défaut (aucune collision
        # possible, règle stricte n° 1 respectée PAR CONSTRUCTION), ou un
        # partage EXPLICITE entre plusieurs acteurs — auquel cas le dialogue
        # émet les règles 'sharedBy' correspondantes, exactement la voie
        # légitime prévue par le compilateur (point 1 du journal).
        managers = {}  # ent -> [acteurs] (1 seul, ou 2+ si partagé)
        for ent in entity_names:
            if len(actors) == 1:
                managers[ent] = [actors[0]]
                continue
            pick = self._ask_choice(
                f"Qui gère {ent} en écriture (création/modification/suppression) ?",
                actors + ["(plusieurs acteurs se partagent la gestion)"])
            if pick != "(plusieurs acteurs se partagent la gestion)":
                managers[ent] = [pick]
                continue
            shared = [a for a in actors
                      if self._ask_yes_no(f"  {a} participe-t-il à la gestion de {ent} ?")]
            if len(shared) < 2:
                self._say("  ✗ Un partage exige au moins deux acteurs — gestion "
                          "attribuée au premier acteur.")
                shared = [shared[0] if shared else actors[0]]
            managers[ent] = shared

        # Propriété par enregistrement (ownedBy) : seul le créateur d'un
        # enregistrement peut le modifier/supprimer. Nécessite une entité
        # "propriétaire" homonyme de l'acteur + la relation qui fournit la
        # colonne de clé étrangère (motif canonique : exemples/03, point 5
        # du journal). Non proposé quand la gestion est partagée (v1).
        owned = {}  # ent -> entité propriétaire
        for ent in entity_names:
            if len(managers[ent]) != 1:
                continue
            actor = managers[ent][0]
            if not self._ask_yes_no(
                    f"Chaque enregistrement de {ent} doit-il appartenir à son "
                    f"créateur (lui seul pourra le modifier/supprimer) ?"):
                continue
            owned[ent] = actor
            if actor not in entities:
                entities[actor] = [("displayName", "String")]
                entity_names.append(actor)
                managers[actor] = [actor]
                self._say(f"  → Entité propriétaire '{actor}' créée automatiquement "
                          f"(displayName: String), reliée par '{actor} hasMany {ent}'.")

        # Lecteurs supplémentaires (les lectures ne créent pas de collision)
        readers = {ent: set() for ent in entity_names}
        for ent in entity_names:
            for act in actors:
                if act in managers[ent]:
                    continue
                if self._ask_yes_no(f"{act} peut-il LIRE {ent} (une fois connecté) ?"):
                    readers[ent].add(act)

        # Relations
        relations = []
        if len(entity_names) >= 2 and self._ask_yes_no("\nDes entités sont-elles liées entre elles ?"):
            while True:
                src = self._ask_choice("Entité source de la relation ?", entity_names + ["(terminer)"])
                if src == "(terminer)":
                    break
                rtype = self._ask_choice(
                    f"Type de lien depuis {src} ? (hasMany : {src} contient plusieurs cibles)",
                    RELATION_TYPES)
                targets = [e for e in entity_names if e != src]
                tgt = self._ask_choice("Entité cible ?", targets)
                relations.append((src, rtype, tgt))
                if not self._ask_yes_no("Ajouter une autre relation ?"):
                    break

        want_seed = self._ask_yes_no("Pré-remplir le site avec des données de démonstration ?")
        want_landing = self._ask_yes_no(
            "Transmettre votre description à l'IA frontend comme brief de page d'accueil ?")

        # Entités propriétaires + relations de propriété (helper partagé
        # avec le chemin « modèle » ; dédupliqué si déjà déclaré à la main).
        readers = {e: readers.get(e, set()) for e in entities}
        managers = {e: managers.get(e, [actors[0]]) for e in entities}
        self._ensure_ownership_structure(entities, managers, readers, owned, relations)

        spec = self._emit_spec(app_name, description, entities, relations, actors,
                               managers, readers, public_read,
                               [public_create] if public_create else [],
                               owned, want_seed, want_landing)

        # Garantie finale : la spec émise DOIT compiler. On la revalide par le
        # vrai pipeline — si ce n'est pas le cas, c'est un bug du moteur, pas
        # de l'utilisateur, et on échoue bruyamment plutôt que de rendre un
        # fichier cassé.
        from parser import parse_monlang_string
        from ast_validator import MonLangAST
        MonLangAST(parse_monlang_string(spec)).validate_and_audit()
        return spec

    # ---------- émission déterministe de la spec ----------
    def _emit_spec(self, app_name, description, entities, relations, actors,
                   managers, readers, public_read, public_create,
                   owned, want_seed, want_landing,
                   extra_rules=(), custom_seeds=None):
        lines = [f"app {app_name}", "",
                 "# Spécification générée par le dialogue guidé MonLang (déterministe, sans IA).",
                 f"# Brief du projet : {description}", ""]

        for ent, fields in entities.items():
            lines.append(f"entity {ent}")
            for fname, ftype in fields:
                lines.append(f"    {fname}: {ftype}")
            lines.append("")

        for src, rtype, tgt in relations:
            lines.append(f"relation {src} {rtype} {tgt}")
        if relations:
            lines.append("")

        for act in actors:
            lines.append(f"actor {act}")
        lines.append("")

        # Règles : premier champ requis, lecture/création publiques
        for ent, fields in entities.items():
            first_field = fields[0][0]
            lines.append(f"rule {ent}.{first_field} required")
        for ent in public_read:
            lines.append(f"rule {ent}.Read public")
        for ent in public_create:
            lines.append(f"rule {ent}.Create public")
        for ent, owner in owned.items():
            lines.append(f"rule {ent}.Update ownedBy {owner}")
            lines.append(f"rule {ent}.Delete ownedBy {owner}")
        for ent in entities:
            if len(managers[ent]) > 1:
                shared_list = ", ".join(managers[ent])
                for action in ("Create", "Update", "Delete"):
                    lines.append(f"rule {ent}.{action} sharedBy {shared_list}")
        # Règles avancées portées par les modèles du catalogue (increments,
        # hidden, categorized…) — émises telles quelles, validées comme tout
        # le reste par le parseur + l'audit en sortie de dialogue.
        lines.extend(extra_rules)
        lines.append("")

        # Workflows : un gestionnaire CRUD complet par entité (jamais de
        # collision d'écriture), puis un workflow de lecture par lecteur.
        for ent in entities:
            for actor in managers[ent]:
                suffix = f"By{actor}" if len(managers[ent]) > 1 else ""
                lines.append(f"workflow Manage{ent}{suffix} for {actor}")
                for action in ("Create", "Read", "Update", "Delete"):
                    lines.append(f"    {action} {ent}")
                lines.append("")
        for act in actors:
            readable = [ent for ent in entities if act in readers[ent]]
            if readable:
                lines.append(f"workflow Browse{act} for {act}")
                for ent in readable:
                    lines.append(f"    Read {ent}")
                lines.append("")

        if want_seed:
            custom_seeds = custom_seeds or {}
            # Données réalistes du modèle en priorité ; repli générique pour
            # les entités publiques qui n'en ont pas.
            for ent, rows in custom_seeds.items():
                if not rows or ent not in entities:
                    continue
                lines.append(f"seed {ent}")
                for row in rows:
                    parts = [f"{f}: {self._literal(v)}" for f, v in row.items()]
                    lines.append("    " + ", ".join(parts))
                lines.append("")
            for ent in public_read:
                if ent in custom_seeds:
                    continue
                seedable = [(f, t) for f, t in entities[ent] if t in SEEDABLE_TYPES]
                if not seedable:
                    continue
                lines.append(f"seed {ent}")
                for n in (1, 2, 3):
                    parts = [f"{f}: {self._seed_value(f, t, n)}" for f, t in seedable]
                    lines.append("    " + ", ".join(parts))
                lines.append("")

        if want_landing:
            lines.append("landing")
            lines.append(f'    brief: "{description}"')
            lines.append("")

        return "\n".join(lines)

    @staticmethod
    def _literal(value):
        """Valeur de seed -> littéral DSL (la grammaire n'accepte que
        STRING_LITERAL et SIGNED_NUMBER)."""
        if isinstance(value, bool):
            raise DialogueError("un seed ne peut pas contenir de booléen (grammaire)")
        if isinstance(value, (int, float)):
            return str(value)
        return '"' + str(value).replace('"', "'") + '"'

    @staticmethod
    def _seed_value(field_name, ftype, n):
        low = field_name.lower()
        if ftype in ("Integer",):
            return str(n * 10)
        if ftype in ("Float", "Money"):
            return f"{n * 10}.5"
        if ftype == "Email":
            return f'"demo{n}@exemple.fr"'
        if any(k in low for k in ("image", "photo", "url", "cover", "avatar")):
            return f'"https://picsum.photos/seed/demo{n}/800/600"'
        if ftype == "Text":
            return f'"Contenu de démonstration numéro {n}, généré par le dialogue guidé."'
        return f'"Exemple {n}"'


def run_interactive_dialogue(interpreter=None):
    """Point d'entrée réel (stdin/stdout) utilisé par cli.py. 'interpreter'
    active la compréhension des réponses libres (modèle local, point 44)."""
    dialogue = GuidedDialogue(ask=input, say=print, interpreter=interpreter)
    return dialogue.run()
