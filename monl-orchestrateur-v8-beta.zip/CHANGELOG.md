# Journal des modifications

## 0.9.0-beta.2 — Retrait de l'IA générative locale

Le compilateur devient entièrement déterministe. La seule IA du cycle de vie est
désormais celle qui construit le frontend (Claude), contre le contrat.

### Retiré
- Suppression complète d'Ollama et des modules associés (`nl_interpreter.py`,
  `ai_translator.py`, `ai_sandbox_filler.py`).
- Options retirées : `--nl` (réponses libres au dialogue), `--prompt` (spec
  depuis une description), `--fill-custom` (remplissage des blocs `custom`).
- Le dialogue guidé est purement à saisie stricte ; les blocs `custom` sont des
  coquilles vides à compléter à la main (aucune génération de code automatisée).

### Corrigé
- Défaut de compilation mort supprimé (référence à un exemple inexistant).
- Documentation alignée (README, `docs/SECURITE.md`, `docs/BETA.md`) : plus
  aucune mention d'Ollama ni d'IA générative dans le cœur du produit.

## 0.9.0-beta.1 — Première bêta

Correction de tous les défauts bloquants identifiés à l'audit. Détail dans
`docs/BETA.md` ; modèle de sécurité dans `docs/SECURITE.md`.

> Note : certains éléments décrits ci-dessous (bloc `custom` par IA locale,
> garde-fou du code généré) ont été retirés en 0.9.0-beta.2. Entrée conservée
> comme historique.

### Sécurité
- Bloc `custom` désactivé par défaut ; activation explicite par `--fill-custom`.
  La compilation nominale est désormais 100 % déterministe et hors-ligne.
- Garde-fou statique du code `custom` durci : blocage des évasions par
  introspection (`__class__`, `__subclasses__`, `__globals__`, `__code__`,
  `__mro__`…), détection élargie des boucles à condition constamment vraie,
  liste d'imports bas-niveau étendue (`inspect`, `threading`, `marshal`, `gc`…).
- Comparaison à temps constant (`hmac.compare_digest`) des empreintes de mot de
  passe à la connexion.
- Secret JWT injectable par variable d'environnement `MONL_JWT_SECRET`
  (prioritaire sur le fichier `.jwt_secret`) — le secret peut ne jamais toucher
  le disque en production.
- Limitation de débit consciente du proxy via `MONL_TRUST_PROXY` ;
  `X-Forwarded-For` ignoré par défaut pour empêcher l'usurpation d'IP.

### Fiabilité
- Intégrité transactionnelle : création d'un enregistrement et effets liés
  (`increments`/`decrements`) exécutés dans une seule transaction avec rollback.

### Packaging & documentation
- `pyproject.toml` (métadonnées, entrée console `monl`, config pytest).
- Dépendances épinglées avec bornes hautes (`requirements.txt` + `pyproject.toml`).
- Nouveaux documents : `docs/SECURITE.md`, `docs/BETA.md`.
- Nouveau test : `tests/test_sandbox_guardrail.py` (20 cas, dont évasions par
  introspection).
- Archive de distribution nettoyée (aucun secret ni artefact généré).
