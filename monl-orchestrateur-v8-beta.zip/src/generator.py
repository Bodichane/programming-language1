import os
import secrets
import hashlib
import json
import colorsys
import re
import html
from ast_validator import MonlAST
from parser import parse_monl_file

class MonlSecureGenerator:
    def __init__(self, normalized_ast, output_dir=None):
        # AJOUT (roadmap, compilation multi-projets) : 'output_dir' permet de
        # compiler chaque spec dans son propre dossier (option --output de
        # main.py) au lieu d'écraser systématiquement les artefacts à la
        # racine du dépôt. Par défaut (None), le comportement historique est
        # conservé : tout est écrit à la racine du dépôt.
        default_root = os.path.join(os.path.dirname(__file__), "..")
        self.output_dir = os.path.abspath(output_dir or default_root)
        os.makedirs(self.output_dir, exist_ok=True)
        self.ast = normalized_ast
        self.app_name = normalized_ast["meta"]["appName"]
        self.entities = normalized_ast["schema"]["entities"]
        self.relations = normalized_ast["schema"]["relations"]
        self.workflows = normalized_ast["security"]["workflows"]
        self.actors = normalized_ast["security"]["actors"]
        self.custom_functions = normalized_ast["sandbox_ai"]["custom_functions"]
        # AJOUT (post-v6, roadmap) : map "Entite.Action" -> entité propriétaire,
        # issue des règles 'ownedBy' validées par ast_validator.py.
        self.ownership = normalized_ast["security"].get("ownership", {})
        # AJOUT (roadmap, brique "accès à deux parties") : table
        # {"Entite.Action": [colonnes]} issue des règles 'accessibleBy'
        # validées par ast_validator.py — chaque colonne contient
        # l'identifiant d'un utilisateur autorisé sur l'enregistrement.
        self.access_parties = normalized_ast["security"].get("access_parties", {})
        # AJOUT (roadmap, cas d'usage portfolio) : ensemble des "Entite.Action"
        # marquées 'public' — ces routes ne requièrent aucune authentification.
        # Reconstruit en tuples (entité, action) pour être comparable
        # directement à (base_target, act_type) lors de la génération des routes.
        self.public_actions = {
            tuple(ref.split(".", 1)) for ref in normalized_ast["security"].get("public", [])
        }
        # AJOUT (roadmap, écosystème de capacités -- brique 2) : ensemble des
        # "Entite.champ" marquées 'hidden' — voir _generate_secure_fastapi,
        # où ces champs sont retirés des réponses de lecture (liste et
        # détail) de leur entité, quel que soit qui appelle la route.
        # Regroupé par entité (plutôt qu'un set de tuples comme
        # public_actions) car c'est la forme directement utile à la
        # génération : "quels champs retirer pour CETTE entité".
        self.hidden_fields_by_entity = {}
        for ref in normalized_ast["security"].get("hidden_fields", []):
            entity, field = ref.split(".", 1)
            self.hidden_fields_by_entity.setdefault(entity, []).append(field)
        # AJOUT (roadmap, écosystème de capacités -- brique 3, généralisée en
        # brique 4) : règles 'decrements'/'increments' regroupées par entité
        # déclenchante — voir _generate_secure_fastapi, où la route Create de
        # cette entité gagne une étape supplémentaire après l'insertion
        # (incrémenter/décrémenter le champ ciblé sur la ligne liée,
        # retrouvée via la colonne de clé étrangère que la relation validée
        # garantit d'exister).
        self.reputation_rules_by_trigger = {}
        for r in normalized_ast["security"].get("reputation_rules", []):
            self.reputation_rules_by_trigger.setdefault(r["trigger_entity"], []).append(r)
        # AJOUT (roadmap, écosystème de capacités -- brique 5) : règles
        # 'categorized' regroupées par entité — voir _generate_secure_fastapi,
        # où les routes Read (liste + détail) de cette entité remplacent le
        # champ numérique ciblé par son libellé de catégorie avant de
        # renvoyer la réponse.
        self.categorized_fields_by_entity = {}
        for cf in normalized_ast["security"].get("categorized_fields", []):
            self.categorized_fields_by_entity.setdefault(cf["entity"], []).append(cf)
        # AJOUT (roadmap, écosystème de capacités -- suite de la brique 1) :
        # champs 'generated' regroupés par entité -- retirés du schéma
        # Pydantic de la route Create (le client ne peut même pas tenter de
        # les fournir) et peuplés depuis le pseudonyme anonyme du compte
        # courant plutôt que depuis le corps de requête.
        self.generated_fields_by_entity = {}
        for gf in normalized_ast["security"].get("generated_fields", []):
            self.generated_fields_by_entity.setdefault(gf["entity"], []).append(gf["field"])
        # AJOUT (roadmap, contrôle du rendu visuel) : surcharges explicites du
        # thème/ordre/champ principal par entité, issues des blocs 'ui'.
        self.ui_overrides = normalized_ast.get("ui", {})
        # AJOUT (roadmap, écosystème de capacités -- brique 1) : capacités
        # déclarées via 'capability'. Purement informatif à ce stade -- rien
        # dans generate_all() ne branche encore dessus, puisque
        # l'authentification (seule capacité connue pour l'instant) est déjà
        # générée systématiquement quoi qu'il arrive. Les capacités futures
        # (masquage de champ, accès à deux parties) seront les premières à
        # réellement changer un comportement de génération selon ce qui est
        # déclaré ici.
        self.capabilities = normalized_ast.get("capabilities", [])
        # AJOUT (roadmap frontend, bloc 'seed') : données de démonstration à
        # insérer au démarrage si les tables sont vides (voir init_db).
        self.seeds = normalized_ast.get("seeds", [])

    def _compute_fk_placements(self):
        """CORRECTIF (roadmap) : jusqu'ici, seul le type de relation 'hasMany'
        produisait réellement une colonne de clé étrangère — 'belongsTo' et
        'hasOne' étaient acceptés par la grammaire mais totalement ignorés par
        le générateur (aucune colonne, aucun effet). Cette méthode calcule,
        pour les 3 types de relation, quelle entité porte la colonne de clé
        étrangère et vers quelle entité "propriétaire" elle pointe :
          - hasMany  : "A hasMany B" -> B porte la colonne a_id (A est parent)
          - hasOne   : idem hasMany, avec en plus une contrainte UNIQUE (1-1)
          - belongsTo: "A belongsTo B" -> A porte la colonne b_id (B est parent)
        Retourne : {entité_qui_porte_la_colonne: [{"fk_column", "owner_entity", "unique"}]}
        """
        placements = {}
        for rel in self.relations:
            if rel["type"] in ("hasMany", "hasOne"):
                owner_entity, held_entity = rel["source"], rel["target"]
            elif rel["type"] == "belongsTo":
                owner_entity, held_entity = rel["target"], rel["source"]
            else:
                continue
            placements.setdefault(held_entity, []).append({
                "fk_column": f"{owner_entity.lower()}_id",
                "owner_entity": owner_entity,
                "unique": rel["type"] == "hasOne",
            })
        return placements

    def _get_incoming_relation(self, entity):
        """Retourne la première relation entrante sur 'entity' (hasMany, hasOne,
        ou belongsTo — toutes désormais gérées, voir _compute_fk_placements),
        celle qui fournit la colonne de clé étrangère dans schema.sql, ou None
        s'il n'y en a pas. Utilisé pour peupler cette colonne à la création et
        pour le contrôle d'accès par propriété ('ownedBy')."""
        placements = self._compute_fk_placements().get(entity, [])
        if not placements:
            return None
        first = placements[0]
        return {"source": first["owner_entity"], "fk_column": first["fk_column"]}

    def generate_all(self):
        """Déclenche la génération déterministe du BACKEND et les coquilles
        vides des blocs 'custom' (à compléter à la main). PIVOT (point 41 de
        docs/design_decisions.md) : monl ne génère plus AUCUN frontend
        (landing, dashboard, archétypes — tous retirés). L'interface est
        déléguée à une IA spécialisée via le contrat frontend
        (frontend_contract.json + FRONTEND_PROMPT.md, voir
        src/frontend_contract.py) ; '/docs' (Swagger) reste le seul front
        fourni, gratuitement, par FastAPI."""
        print(f"🏗️  Génération du socle déterministe réel pour '{self.app_name}'...")
        if self.capabilities:
            print(f"🧩 Capacités déclarées : {', '.join(self.capabilities)} (voir docs/design_decisions.md point 24).")
        
        sql_content = self._generate_sql()
        api_content = self._generate_secure_fastapi()
        sandbox_content = self._generate_ai_sandbox()
        
        # Détermination des chemins physiques (racine du dépôt par défaut,
        # ou dossier passé via --output — voir __init__).
        base_dir = self.output_dir
        sql_path = os.path.join(base_dir, "schema.sql")
        api_path = os.path.join(base_dir, "app.py")
        sandbox_path = os.path.join(base_dir, "sandbox_ai.py")
        secret_path = os.path.join(base_dir, ".jwt_secret")

        # CORRECTIF (roadmap, faille signalée) : le secret JWT était jusqu'ici
        # une chaîne fixe codée en dur dans generator.py, IDENTIQUE dans
        # absolument toutes les applications générées par monl. Un token
        # forgé pour une app était donc valide sur n'importe quelle autre
        # app générée par le même compilateur — quiconque lit le code source
        # public de monl connaît la clé secrète de toutes les applications
        # qui en sont issues. Un secret aléatoire de 32 octets est désormais
        # généré une seule fois par projet, à la première compilation, et
        # conservé dans '.jwt_secret' (à ajouter au .gitignore, jamais commité).
        # Recompiler la spec NE régénère PAS ce secret (pour ne pas invalider
        # les sessions déjà émises) — il faut le supprimer manuellement pour
        # en forcer le renouvellement.
        if not os.path.exists(secret_path):
            new_secret = secrets.token_hex(32)
            with open(secret_path, "w", encoding="utf-8") as f:
                f.write(new_secret)
            print(f"🔑 Nouveau secret JWT généré et stocké dans '.jwt_secret' (32 octets, aléatoire, propre à ce projet).")
        else:
            print("🔑 Secret JWT existant conservé ('.jwt_secret' déjà présent).")

        with open(sql_path, "w", encoding="utf-8") as f: f.write(sql_content)
        with open(api_path, "w", encoding="utf-8") as f: f.write(api_content)
        with open(sandbox_path, "w", encoding="utf-8") as f: f.write(sandbox_content)

        print("💾 Socle généré : 'schema.sql', 'app.py' et 'sandbox_ai.py' sont prêts !")


    def _compute_seed_data(self):
        """AJOUT (roadmap frontend, bloc 'seed') : regroupe les données de
        démonstration par nom de table (lowercase), dans l'ordre de
        déclaration. Retourne {table: [ {champ: valeur}, ... ]}. Plusieurs
        blocs 'seed' visant la même entité sont concaténés.

        Les champs 'generated' (ex. pseudonyme anonyme d'auteur) ne sont pas
        renseignés par l'utilisateur dans le seed (le validateur le tolère
        car ils sont retirés du schéma d'entrée) ; comme à la création réelle
        ils sont assignés par le serveur, on leur donne ici une valeur
        synthétique déterministe ('Anon#1000', 'Anon#1001'…) pour que le seed
        produise des enregistrements complets et cohérents avec le rendu
        (fil social, etc.)."""
        seed_data = {}
        for seed in self.seeds:
            entity = seed["entity"]
            table = entity.lower()
            generated = self.generated_fields_by_entity.get(entity, [])
            seed_data.setdefault(table, [])
            for row in seed["rows"]:
                filled = dict(row)
                for gfield in generated:
                    if gfield not in filled:
                        # Pseudonyme synthétique stable, unique par ligne.
                        filled[gfield] = f"Anon#{1000 + len(seed_data[table])}"
                seed_data[table].append(filled)
        return seed_data

    def _compute_expected_columns(self):
        """AJOUT (roadmap long terme, migrations sans perte de données) :
        retourne {nom_table: [(colonne, type_sql), ...]} pour toutes les
        tables métier, dans l'ordre exact de _generate_sql (attributs
        déclarés puis clés étrangères entrantes). L'id n'y figure pas : il
        est toujours créé par le CREATE TABLE initial et n'est jamais
        ajouté a posteriori. Sert à init_db() pour détecter, au démarrage,
        les colonnes présentes dans la spec mais absentes d'une base déjà
        créée, et les ajouter par ALTER TABLE ADD COLUMN — opération
        purement additive, qui ne touche ni ne supprime aucune donnée
        existante."""
        fk_placements = self._compute_fk_placements()
        expected = {}
        for ent_name, attrs in self.entities.items():
            table = ent_name.lower()
            columns = []
            for attr_name, attr_type in attrs.items():
                columns.append((attr_name, self._map_type_to_sql(attr_type)))
            for placement in fk_placements.get(ent_name, []):
                columns.append((placement["fk_column"], "INTEGER"))
            expected[table] = columns
        return expected

    def _map_type_to_sql(self, type_str):
        mapping = {
            "String": "VARCHAR(255)", "Text": "TEXT", "Integer": "INTEGER",
            "Float": "REAL", "Boolean": "BOOLEAN", "Date": "DATE",
            "DateTime": "TIMESTAMP", "Email": "VARCHAR(255)", "UUID": "UUID", "Money": "NUMERIC(10, 2)"
        }
        return mapping.get(type_str, "TEXT")

    def _get_row_column_names(self, entity):
        """Reconstruit l'ordre exact des colonnes SQL d'une entité (id, puis
        attributs déclarés dans l'ordre, puis clé(s) étrangère(s) entrante(s)),
        pour convertir les tuples renvoyés par sqlite3 en objets nommés côté
        API plutôt que des tableaux positionnels — nécessaire pour un rendu
        front lisible (roadmap : front visuel, pas de JSON brut)."""
        columns = ["id"] + list(self.entities[entity].keys())
        for placement in self._compute_fk_placements().get(entity, []):
            columns.append(placement["fk_column"])
        return columns

    def _emit_categorization_lines(self, categorized_field, row_var, indent):
        """AJOUT (roadmap, écosystème de capacités -- brique 5) : génère le
        code source Python qui remplace, sur un dict de ligne déjà nommé
        (row_var), un champ numérique par son libellé de catégorie
        (ex. 'likes' -> 'likes_category'). La validation dans
        ast_validator.py garantit que 'clauses' se termine toujours par
        exactement un palier 'otherwise', et que tous les paliers 'below'
        qui précèdent sont strictement croissants -- donc la chaîne
        if/elif/.../else générée ici est toujours syntaxiquement valide et
        couvre nécessairement toute valeur possible."""
        field = categorized_field["field"]
        clauses = categorized_field["clauses"]
        cat_key = f"{field}_category"
        # repr() plutôt qu'une interpolation manuelle entre guillemets : le
        # libellé vient d'un STRING_LITERAL utilisateur et peut contenir des
        # apostrophes/antislashs -- repr() produit toujours un littéral
        # Python syntaxiquement valide, quel que soit le contenu.
        lines = [f"{indent}_v = {row_var}.pop('{field}')"]
        for i, clause in enumerate(clauses):
            label_literal = repr(clause["label"])
            if "otherwise" in clause:
                lines.append(f"{indent}else: {row_var}['{cat_key}'] = {label_literal}")
            else:
                keyword = "if" if i == 0 else "elif"
                lines.append(f"{indent}{keyword} _v < {clause['below']}: {row_var}['{cat_key}'] = {label_literal}")
        return lines

    def _generate_sql(self):
        """Génère un schéma SQL déterministe préservant les données existantes (Bug #3)."""
        sql_lines = [f"-- Socle DB Déterministe généré automatiquement pour {self.app_name}\n"]

        # AJOUT (roadmap) : table système du registre d'utilisateurs réel. Elle
        # existe indépendamment de la spec (toute application générée en a
        # besoin pour /register et /login), donc elle est injectée ici plutôt
        # que déclarée par l'utilisateur dans le DSL.
        sql_lines.append("CREATE TABLE IF NOT EXISTS _monl_users (")
        sql_lines.append("    id INTEGER PRIMARY KEY AUTOINCREMENT,")
        sql_lines.append("    username VARCHAR(255) UNIQUE NOT NULL,")
        sql_lines.append("    password_hash VARCHAR(255) NOT NULL,")
        sql_lines.append("    salt VARCHAR(255) NOT NULL,")
        sql_lines.append("    actor VARCHAR(255) NOT NULL,")
        # AJOUT (roadmap, écosystème de capacités -- suite de la brique 1) :
        # pseudonyme anonyme stable, généré une seule fois à l'inscription
        # (voir /register), indépendant de la spec -- toujours présent,
        # utilisé seulement si un champ 'generated' le référence.
        sql_lines.append("    anon_handle VARCHAR(255) UNIQUE NOT NULL")
        sql_lines.append(");\n")

        # AJOUT (roadmap, révocation de token) : liste noire persistante des
        # tokens explicitement révoqués via /logout, avant leur expiration
        # naturelle.
        sql_lines.append("CREATE TABLE IF NOT EXISTS _monl_revoked_tokens (")
        sql_lines.append("    jti VARCHAR(64) PRIMARY KEY,")
        sql_lines.append("    revoked_at TIMESTAMP NOT NULL")
        sql_lines.append(");\n")

        # AJOUT (roadmap long terme, rate limiting multi-workers) : la
        # limitation de débit était jusqu'ici un dictionnaire en mémoire de
        # processus (_RATE_LIMIT_ATTEMPTS), donc NON partagé entre plusieurs
        # workers uvicorn/gunicorn : un attaquant réparti sur N workers
        # obtenait N fois le quota. Chaque tentative est désormais
        # enregistrée en base (partagée par tous les workers), avec l'IP, le
        # bucket ('login'/'register') et l'instant. L'index accélère la
        # fenêtre glissante et la purge.
        sql_lines.append("CREATE TABLE IF NOT EXISTS _monl_rate_limit (")
        sql_lines.append("    bucket VARCHAR(32) NOT NULL,")
        sql_lines.append("    client_ip VARCHAR(64) NOT NULL,")
        sql_lines.append("    attempted_at REAL NOT NULL")
        sql_lines.append(");")
        sql_lines.append('CREATE INDEX IF NOT EXISTS idx_rate_limit_lookup ON _monl_rate_limit (bucket, client_ip, attempted_at);\n')

        # CORRECTIF (roadmap) : placement des FK généralisé aux 3 types de
        # relation (hasMany, hasOne, belongsTo) via _compute_fk_placements,
        # au lieu de ne traiter que 'hasMany' comme précédemment.
        fk_placements = self._compute_fk_placements()

        for ent_name, attrs in self.entities.items():
            # CORRECTIF (roadmap, bug signalé -- collision avec un mot-clé SQL
            # réservé) : une entité nommée "Order" (ou toute autre déclarée
            # dans la spec qui coïncide avec un mot-clé SQLite comme ORDER,
            # GROUP, SELECT...) faisait échouer schema.sql sans que rien ne le
            # signale clairement à la compilation -- juste une erreur SQL
            # silencieuse au démarrage du serveur. Les noms de table ET de
            # colonne sont désormais systématiquement entre guillemets
            # doubles (échappement d'identifiant standard SQL, supporté par
            # SQLite), qu'ils entrent ou non en collision -- plus fiable que
            # de maintenir une liste de mots réservés à jour.
            sql_lines.append(f'CREATE TABLE IF NOT EXISTS "{ent_name.lower()}" (')
            sql_lines.append("    id INTEGER PRIMARY KEY AUTOINCREMENT,")
            for attr_name, attr_type in attrs.items():
                sql_type = self._map_type_to_sql(attr_type)
                sql_lines.append(f'    "{attr_name}" {sql_type},')

            # CORRECTIF (roadmap, second bug -- masqué jusqu'ici par le
            # premier) : les colonnes de clé étrangère et leur contrainte
            # 'FOREIGN KEY' étaient auparavant émises l'une après l'autre,
            # par relation. Dès qu'une entité a 2 relations ou plus (ex.
            # OrderItem -> Order ET Product), ça produit une colonne après
            # une contrainte de table -- invalide en SQL standard (SQLite y
            # compris) : toutes les définitions de colonnes doivent précéder
            # toute contrainte de table. Les colonnes FK sont maintenant
            # toutes déclarées d'abord, puis toutes les contraintes
            # 'FOREIGN KEY' ensuite.
            for placement in fk_placements.get(ent_name, []):
                fk_col = placement["fk_column"]
                unique_kw = " UNIQUE" if placement["unique"] else ""
                sql_lines.append(f'    "{fk_col}" INTEGER{unique_kw},')

            for placement in fk_placements.get(ent_name, []):
                fk_col = placement["fk_column"]
                owner_table = placement["owner_entity"].lower()
                sql_lines.append(f'    FOREIGN KEY ("{fk_col}") REFERENCES "{owner_table}"(id),')

            sql_lines[-1] = sql_lines[-1].rstrip(",")
            sql_lines.append(");\n")
        return "\n".join(sql_lines)

    def _generate_secure_fastapi(self):
        """Génère l'API avec persistance SQLite, authentification JWT et schémas IA stricts."""
        actors_literal = ", ".join(f'"{a}"' for a in self.actors)
        api_lines = [
            "# API Déterministe Sécurisée par défaut - Ne pas modifier à la main",
            "from fastapi import FastAPI, HTTPException, Header, Depends, Request",
            "from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials",
            "from pydantic import BaseModel",
            "from typing import List, Optional, Any",
            "import sqlite3",
            "import jwt",
            "import datetime",
            "import hashlib",
            "import hmac",
            "import os",
            "import secrets",
            "import sandbox_ai  # Fonctions 'custom' écrites à la main (module isolé)\n",
            f"app = FastAPI(title='{self.app_name} - Secure Core')",
            "DB_FILE = 'app.db'",
            # CORRECTIF (bêta, hygiène de secret) : le secret JWT est lu en
            # priorité depuis la variable d'environnement MONL_JWT_SECRET
            # (recommandé en production — le secret ne touche jamais le disque
            # ni un dépôt), et retombe sinon sur le fichier '.jwt_secret'
            # généré à la compilation. Un projet peut ainsi être livré SANS
            # secret embarqué et se le voir injecter au déploiement.
            "JWT_SECRET = (os.environ.get('MONL_JWT_SECRET') or '').strip()",
            "if not JWT_SECRET:",
            "    try:",
            "        with open('.jwt_secret', 'r', encoding='utf-8') as _f:",
            "            JWT_SECRET = _f.read().strip()",
            "        if not JWT_SECRET:",
            "            raise ValueError('.jwt_secret est vide')",
            "    except (FileNotFoundError, ValueError) as _e:",
            "        raise RuntimeError(",
            "            \"Aucun secret JWT : définissez la variable d'environnement \"",
            "            \"MONL_JWT_SECRET, ou laissez le compilateur monl générer \"",
            "            \"'.jwt_secret' (relancez 'python3 src/main.py <spec.ml>' depuis la \"",
            "            \"racine du projet avant de démarrer le serveur).\"",
            "        ) from _e",
            "JWT_ALGORITHM = 'HS256'",
            f"VALID_ACTORS = [{actors_literal}]\n",
            "# AJOUT (roadmap long terme, migrations sans perte de données) :",
            "# schéma de colonnes attendu par table (hors 'id'), consommé par",
            "# init_db() pour appliquer les ALTER TABLE ADD COLUMN manquants au",
            "# démarrage. Injecté via repr() pour un littéral Python toujours",
            "# valide, quel que soit le nom des colonnes.",
            f"_EXPECTED_COLUMNS = {repr(self._compute_expected_columns())}\n",
            "# AJOUT (roadmap frontend, bloc 'seed') : données de démonstration",
            "# regroupées par table, injectées via repr() pour un littéral toujours",
            "# valide. Consommées par init_db() (insertion idempotente si vide).",
            f"_SEED_DATA = {repr(self._compute_seed_data())}\n",
            "security_bearer = HTTPBearer()\n",
            # CORRECTIF (roadmap, révocation de token) : la vérification du
            # token est centralisée dans une seule fonction, appelée par les
            # deux dépendances ci-dessous — avant, chacune redécodait le token
            # indépendamment, ce qui aurait pu faire oublier la vérification
            # de révocation dans l'une des deux lors d'une future modification.
            "def _decode_and_verify_token(credentials: HTTPAuthorizationCredentials) -> dict:",
            "    try:",
            "        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])",
            "    except jwt.PyJWTError:",
            "        raise HTTPException(status_code=401, detail='Token invalide ou expiré')",
            "    jti = payload.get('jti')",
            "    if jti:",
            "        conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()",
            "        cursor.execute('SELECT 1 FROM _monl_revoked_tokens WHERE jti = ?', (jti,))",
            "        revoked = cursor.fetchone(); conn.close()",
            "        if revoked:",
            "            raise HTTPException(status_code=401, detail='Ce token a été révoqué (déconnexion effectuée).')",
            "    return payload\n",

            "def verify_jwt_and_get_actor(credentials: HTTPAuthorizationCredentials = Depends(security_bearer)) -> str:",
            "    return _decode_and_verify_token(credentials).get('actor')\n",

            # AJOUT (post-v6, roadmap) : dépendance séparée pour récupérer l'identité
            # numérique (user_id) portée par le token, utilisée par le contrôle
            # d'accès par propriété ('ownedBy') et par le peuplement automatique
            # des colonnes de clé étrangère à la création d'un enregistrement.
            "def get_current_user_id(credentials: HTTPAuthorizationCredentials = Depends(security_bearer)) -> int:",
            "    return _decode_and_verify_token(credentials).get('user_id', 0)\n",

            # AJOUT (roadmap, écosystème de capacités -- suite de la brique 1) :
            # dépendance séparée pour récupérer le pseudonyme anonyme stable
            # du compte courant, utilisée par les champs 'generated' -- déjà
            # porté par le JWT depuis /login (voir plus bas), pas besoin
            # d'une requête DB supplémentaire à chaque appel.
            "def get_current_anon_handle(credentials: HTTPAuthorizationCredentials = Depends(security_bearer)) -> str:",
            "    return _decode_and_verify_token(credentials).get('anon_handle', '')\n",
            
            "@app.on_event('startup')",
            "def init_db():",
            "    conn = sqlite3.connect(DB_FILE)",
            "    try:",
            "        with open('schema.sql', 'r', encoding='utf-8') as f:",
            "            conn.executescript(f.read())",
            "    except Exception as e:",
            "        print(f'ℹ️ DB déjà initialisée ou erreur de script: {e}')",
            "    # AJOUT (roadmap long terme, migrations sans perte de données) :",
            "    # après le CREATE TABLE IF NOT EXISTS (qui ne modifie jamais une",
            "    # table déjà présente), on rattrape les colonnes ajoutées à la",
            "    # spec depuis la dernière compilation. Pour chaque table, on",
            "    # compare les colonnes attendues aux colonnes réelles",
            "    # (PRAGMA table_info) et on ajoute les manquantes par ALTER TABLE",
            "    # ADD COLUMN — opération purement additive : aucune donnée",
            "    # existante n'est lue, déplacée ou supprimée. Les colonnes",
            "    # retirées de la spec sont laissées en place (SQLite ne supporte",
            "    # pas DROP COLUMN sans reconstruction, et les supprimer",
            "    # détruirait des données — voir docs/MIGRATIONS.md).",
            "    try:",
            "        _cur = conn.cursor()",
            "        for _table, _cols in _EXPECTED_COLUMNS.items():",
            "            _cur.execute('SELECT name FROM sqlite_master WHERE type=\"table\" AND name=?', (_table,))",
            "            if _cur.fetchone() is None:",
            "                continue  # table absente : le CREATE l'a déjà couverte, ou spec sans données",
            "            _cur.execute(f'PRAGMA table_info(\"{_table}\")')",
            "            _existing = {_row[1] for _row in _cur.fetchall()}",
            "            for _col, _sql_type in _cols:",
            "                if _col not in _existing:",
            "                    _cur.execute(f'ALTER TABLE \"{_table}\" ADD COLUMN \"{_col}\" {_sql_type}')",
            "                    print(f'🔧 Migration : colonne \"{_col}\" ajoutée à \"{_table}\" ({_sql_type}).')",
            "        conn.commit()",
            "    except Exception as e:",
            "        print(f'⚠️ Migration additive ignorée : {e}')",
            "    # AJOUT (roadmap frontend, bloc 'seed') : insertion des données de",
            "    # démonstration si (et seulement si) la table est VIDE — idempotent,",
            "    # donc un redémarrage n'empile pas les doublons, et des données",
            "    # réelles créées par l'utilisateur ne sont jamais écrasées.",
            "    try:",
            "        _scur = conn.cursor()",
            "        for _table, _rows in _SEED_DATA.items():",
            "            _scur.execute(f'SELECT COUNT(*) FROM \"{_table}\"')",
            "            if _scur.fetchone()[0] > 0:",
            "                continue  # déjà des données : on ne touche à rien",
            "            for _row in _rows:",
            "                _cols = list(_row.keys())",
            "                _placeholders = ', '.join(['?'] * len(_cols))",
            "                _colnames = ', '.join(f'\"{_c}\"' for _c in _cols)",
            "                _scur.execute(f'INSERT INTO \"{_table}\" ({_colnames}) VALUES ({_placeholders})', tuple(_row.values()))",
            "            if _rows:",
            "                print(f'🌱 Données de démonstration insérées dans \"{_table}\" ({len(_rows)}).')",
            "        conn.commit()",
            "    except Exception as e:",
            "        print(f'⚠️ Données de démonstration ignorées : {e}')",
            "    finally:",
            "        conn.close()\n",

            # Redirection de la racine vers la documentation Swagger/OpenAPI
            # auto-générée par FastAPI — le seul front que monl fournit
            # encore (pivot, point 41) : l'interface réelle vient de l'IA
            # frontend, servie sur '/site' par 'monl run' (wrapper serve.py).
            "from fastapi.responses import RedirectResponse\n",
            "@app.get('/', include_in_schema=False)",
            "async def root():",
            "    return RedirectResponse(url='/docs')\n",
        ]

        api_lines += [

            # CORRECTIF (roadmap) : remplacement du modèle "actor/user_id
            # auto-déclarés par le client" par un vrai registre d'utilisateurs
            # (table _monl_users, mot de passe haché avec sel via PBKDF2-
            # HMAC-SHA256, 100 000 itérations — pas de dépendance externe type
            # bcrypt nécessaire). LIMITE ASSUMÉE (prototype) : pas de politique
            # de mot de passe, pas de vérification d'email, pas de récupération
            # de compte — voir docs/design_decisions.md.
            "class RegisterRequest(BaseModel):",
            "    username: str",
            "    password: str",
            "    actor: str\n",
            "def _hash_password(password: str, salt_hex: str) -> str:",
            "    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt_hex), 100_000).hex()\n",

            # CORRECTIF (roadmap) : limitation de débit généralisée à un
            # nom de "bucket" (au lieu d'être câblée uniquement pour /login),
            # pour pouvoir protéger /register également — sans ça, /register
            # pouvait être utilisée pour créer des comptes en masse ou pour
            # énumérer les noms d'utilisateur déjà pris (via le code 409).
            # LIMITE ASSUMÉE (prototype) : compteur en mémoire du processus,
            # non distribué, remis à zéro au redémarrage du serveur —
            # suffisant pour freiner un script naïf, pas une attaque distribuée
            # à grande échelle (nécessiterait Redis ou équivalent en prod).
            "RATE_LIMIT_WINDOW_SECONDS = 60",
            "RATE_LIMIT_MAX_ATTEMPTS = 5\n",
            "# AJOUT (bêta, déploiement derrière un proxy) : par défaut on utilise",
            "# l'IP de la connexion directe (request.client.host). Si l'application",
            "# tourne derrière un reverse proxy de confiance (nginx, Traefik...),",
            "# activer MONL_TRUST_PROXY=1 fait lire la première IP de l'en-tête",
            "# X-Forwarded-For — sinon un client direct pourrait usurper cet en-tête",
            "# pour contourner la limitation de débit. On ne fait donc confiance à",
            "# l'en-tête QUE si l'opérateur l'a explicitement autorisé.",
            "_TRUST_PROXY = os.environ.get('MONL_TRUST_PROXY', '').lower() in ('1', 'true', 'yes')",
            "def _client_ip(request: Request) -> str:",
            "    if _TRUST_PROXY:",
            "        fwd = request.headers.get('x-forwarded-for')",
            "        if fwd:",
            "            return fwd.split(',')[0].strip() or 'unknown'",
            "    return request.client.host if request.client else 'unknown'\n",
            "# AJOUT (roadmap long terme, rate limiting multi-workers) : compteur",
            "# de tentatives persisté en base plutôt qu'en mémoire de processus,",
            "# pour que le quota soit partagé par tous les workers uvicorn/gunicorn",
            "# (voir _monl_rate_limit dans schema.sql). Fenêtre glissante :",
            "# on compte les tentatives récentes, on purge les anciennes, puis on",
            "# enregistre la tentative courante.",
            "def _check_rate_limit(bucket: str, client_ip: str):",
            "    now = datetime.datetime.now(datetime.timezone.utc).timestamp()",
            "    cutoff = now - RATE_LIMIT_WINDOW_SECONDS",
            "    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()",
            "    try:",
            "        cursor.execute('DELETE FROM _monl_rate_limit WHERE attempted_at < ?', (cutoff,))",
            "        cursor.execute('SELECT COUNT(*) FROM _monl_rate_limit WHERE bucket = ? AND client_ip = ? AND attempted_at >= ?', (bucket, client_ip, cutoff))",
            "        recent = cursor.fetchone()[0]",
            "        if recent >= RATE_LIMIT_MAX_ATTEMPTS:",
            "            conn.commit()",
            "            raise HTTPException(status_code=429, detail=f'Trop de tentatives ({bucket}). "
            "Réessayez dans {RATE_LIMIT_WINDOW_SECONDS} secondes.')",
            "        cursor.execute('INSERT INTO _monl_rate_limit (bucket, client_ip, attempted_at) VALUES (?, ?, ?)', (bucket, client_ip, now))",
            "        conn.commit()",
            "    finally:",
            "        conn.close()\n",

            "@app.post('/register', tags=['Authentication'])",
            "async def register(req: RegisterRequest, request: Request):",
            "    _check_rate_limit('register', _client_ip(request))",
            "    if req.actor not in VALID_ACTORS:",
            "        raise HTTPException(status_code=400, detail=f\"Acteur invalide. Acteurs valides : {VALID_ACTORS}\")",
            "    if len(req.password) < 8:",
            "        raise HTTPException(status_code=400, detail='Le mot de passe doit contenir au moins 8 caractères.')",
            "    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()",
            "    cursor.execute('SELECT id FROM _monl_users WHERE username = ?', (req.username,))",
            "    if cursor.fetchone():",
            "        conn.close()",
            "        raise HTTPException(status_code=409, detail=\"Ce nom d'utilisateur existe déjà.\")",
            "    salt_hex = os.urandom(16).hex()",
            "    pwd_hash = _hash_password(req.password, salt_hex)",
            # AJOUT (roadmap, écosystème de capacités -- suite de la brique 1) :
            # pseudonyme anonyme stable, généré une seule fois ici (jamais
            # recalculé, jamais fourni par le client) -- 'Anon#' suivi de 4
            # chiffres aléatoires, avec quelques tentatives en cas de
            # collision (contrainte UNIQUE sur la colonne) plutôt qu'un échec
            # d'inscription pour une coïncidence statistiquement rare.
            "    anon_handle = None",
            "    for _ in range(10):",
            "        _candidate = f'Anon#{secrets.randbelow(9000) + 1000}'",
            "        cursor.execute('SELECT 1 FROM _monl_users WHERE anon_handle = ?', (_candidate,))",
            "        if not cursor.fetchone():",
            "            anon_handle = _candidate",
            "            break",
            "    if anon_handle is None:",
            "        conn.close()",
            "        raise HTTPException(status_code=500, detail='Impossible de générer un pseudonyme unique, réessayez.')",
            "    cursor.execute('INSERT INTO _monl_users (username, password_hash, salt, actor, anon_handle) VALUES (?, ?, ?, ?, ?)',",
            "                   (req.username, pwd_hash, salt_hex, req.actor, anon_handle))",
            "    conn.commit(); new_user_id = cursor.lastrowid; conn.close()",
            "    return {'status': 'success', 'user_id': new_user_id}\n",

            "class LoginRequest(BaseModel):",
            "    username: str",
            "    password: str\n",

            "@app.post('/login', tags=['Authentication'])",
            "async def login(req: LoginRequest, request: Request):",
            "    _check_rate_limit('login', _client_ip(request))",
            "    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()",
            "    cursor.execute('SELECT id, password_hash, salt, actor, anon_handle FROM _monl_users WHERE username = ?', (req.username,))",
            "    row = cursor.fetchone(); conn.close()",
            "    if not row:",
            "        raise HTTPException(status_code=401, detail='Identifiants invalides.')",
            "    db_user_id, stored_hash, salt_hex, actor, anon_handle = row",
            "    if not hmac.compare_digest(_hash_password(req.password, salt_hex), stored_hash):",
            "        raise HTTPException(status_code=401, detail='Identifiants invalides.')",
            "    payload = {",
            "        'sub': req.username,",
            "        'actor': actor,",
            "        'user_id': db_user_id,",
            # AJOUT (roadmap, écosystème de capacités -- suite de la brique 1) :
            # porté par le JWT comme 'actor'/'user_id', pour que les champs
            # 'generated' n'aient jamais besoin d'une requête DB séparée.
            "        'anon_handle': anon_handle,",
            # AJOUT (roadmap, révocation de token) : identifiant unique par
            # token (jti), nécessaire pour pouvoir le révoquer individuellement
            # via /logout sans avoir à invalider tous les tokens de l'utilisateur.
            "        'jti': secrets.token_hex(16),",
            "        'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=2)",
            "    }",
            "    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)",
            "    return {'access_token': token, 'token_type': 'bearer'}\n",

            # AJOUT (roadmap, révocation de token) : /logout enregistre le jti
            # du token courant dans une liste noire persistante — toute
            # présentation ultérieure de ce même token est alors rejetée,
            # même s'il n'a pas encore atteint sa date d'expiration naturelle.
            "@app.post('/logout', tags=['Authentication'])",
            "async def logout(credentials: HTTPAuthorizationCredentials = Depends(security_bearer)):",
            "    payload = _decode_and_verify_token(credentials)",
            "    jti = payload.get('jti')",
            "    if not jti:",
            "        raise HTTPException(status_code=400, detail='Ce token ne supporte pas la révocation (jti manquant).')",
            "    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()",
            "    cursor.execute('INSERT OR IGNORE INTO _monl_revoked_tokens (jti, revoked_at) VALUES (?, ?)',",
            "                   (jti, datetime.datetime.now(datetime.timezone.utc).isoformat()))",
            "    conn.commit(); conn.close()",
            "    return {'status': 'success', 'detail': 'Token révoqué.'}\n",
            "# --- VALIDATION STRICTE DES DONNÉES CRUD (PYDANTIC) ---"
        ]
        
        # 1. Génération des schémas CRUD standards
        for ent_name, attrs in self.entities.items():
            api_lines.append(f"class {ent_name}Schema(BaseModel):")
            # AJOUT (roadmap, écosystème de capacités -- suite de la brique 1) :
            # un champ 'generated' n'apparaît PAS dans le schéma Pydantic --
            # le client ne peut même pas tenter de le fournir dans le corps de
            # requête (comme la colonne de clé étrangère 'ownedBy', qui n'y
            # figure pas non plus). Il est peuplé plus bas, à la création,
            # depuis le pseudonyme anonyme du compte courant.
            generated_here_schema = self.generated_fields_by_entity.get(ent_name, [])
            has_schema_field = False
            for attr_name, attr_type in attrs.items():
                if attr_name in generated_here_schema:
                    continue
                py_type = "str"
                if attr_type == "Integer": py_type = "int"
                if attr_type in ["Float", "Money"]: py_type = "float"
                if attr_type == "Boolean": py_type = "bool"
                api_lines.append(f"    {attr_name}: {py_type}")
                has_schema_field = True
            # AJOUT (roadmap, écosystème de capacités -- brique 3, généralisée
            # en brique 4) : quand la relation entrante de cette entité est
            # la cible d'une règle 'decrements'/'increments' (ex.
            # Report -> Member, ou Like -> Post), sa colonne de clé étrangère
            # n'est PAS de la même nature qu'un "ceci m'appartient" (qui se
            # peuple tout seul depuis l'identité JWT de l'appelant, voir plus
            # bas) : c'est un choix du client ("je signale/j'apprécie CETTE
            # cible précise"), donc un champ normal du corps de requête.
            owner_info_for_schema = self._get_incoming_relation(ent_name)
            if owner_info_for_schema and any(
                r["target_entity"] == owner_info_for_schema["source"]
                for r in self.reputation_rules_by_trigger.get(ent_name, [])
            ):
                api_lines.append(f"    {owner_info_for_schema['fk_column']}: int")
                has_schema_field = True
            # Filet de sécurité syntaxique : si TOUS les attributs d'une
            # entité sont 'generated' (aucun autre champ, pas de colonne FK
            # ajoutée ci-dessus), le corps de la classe serait vide --
            # invalide en Python.
            if not has_schema_field:
                api_lines.append("    pass")
            api_lines.append("\n")

        # 2. Schémas stricts pour les entrées des fonctions 'custom'
        api_lines.append("# --- SCHÉMAS DE VALIDATION DÉDIÉS POUR LA SANDBOX IA ---")
        for func in self.custom_functions:
            func_name = func["name"]
            inputs = func.get("input", [])
            
            api_lines.append(f"class {func_name}InputSchema(BaseModel):")
            if not inputs:
                api_lines.append("    pass")
            else:
                for inp in inputs:
                    if "reference" in inp:
                        ref = inp["reference"]
                        ent, attr = ref.split(".") if "." in ref else (ref, "id")
                        attr_type = self.entities.get(ent, {}).get(attr, "String")
                        py_type = "int" if attr_type == "Integer" else ("float" if attr_type in ["Float", "Money"] else ("bool" if attr_type == "Boolean" else "str"))
                        api_lines.append(f"    {attr.replace('.', '_')}: {py_type}")
                    else:
                        inp_name = inp.get("name", "context")
                        inp_type = inp.get("type", "String")
                        py_type = "int" if inp_type == "Integer" else ("float" if inp_type in ["Float", "Money"] else ("bool" if inp_type == "Boolean" else "str"))
                        api_lines.append(f"    {inp_name}: {py_type}")
            api_lines.append("\n")

        api_lines.append("# --- ENFORCEMENT DU CONTRÔLE D'ACCÈS PAR JWT ET PERSISTANCE ---")

        # CORRECTIF (post-v6) : les routes sont désormais regroupées par couple
        # (type d'action, cible), et non plus générées une fois par workflow.
        # Raison : avant ce correctif, deux workflows différents visant la même
        # action sur la même entité (ex. deux acteurs autorisés à faire "Delete Post"
        # via une règle 'sharedBy') produisaient deux définitions de route FastAPI
        # sur le même chemin ('@app.delete(\"/post/{id}\")' deux fois) — seule la
        # première déclarée restait effectivement joignable, la seconde était
        # silencieusement masquée, et son acteur recevait un 403 malgré une spec
        # valide. Le regroupement ci-dessous fusionne les acteurs autorisés en un
        # seul contrôle d'accès par route, listant tous les acteurs légitimes.
        route_map = self._compute_route_map()

        for (act_type, _key), info in route_map.items():
            allowed_actors = sorted(info["actors"])
            base_target = info["base_target"]
            target = info["target"]
            tag = info["tags"][0]

            # AJOUT (roadmap, cas d'usage portfolio) : une action marquée
            # 'public' via une règle DSL ("rule Entite.Action public") ne
            # requiert plus aucune authentification sur la route générée —
            # ni dépendance JWT, ni contrôle de rôle. Utile pour un contenu
            # librement consultable (portfolio) ou un formulaire ouvert
            # (message de contact) sans exiger de compte.
            is_public = (base_target, act_type) in self.public_actions

            if is_public:
                security_check = "    pass  # Route publique (règle 'public') : aucune authentification requise"
                dependency_injection = ""
            elif len(allowed_actors) == 1:
                security_check = (f'    if current_actor != "{allowed_actors[0]}": '
                                   f'raise HTTPException(status_code=403, detail="Contrôle d\'accès : '
                                   f'Rôle {allowed_actors[0]} requis")')
                dependency_injection = "current_actor: str = Depends(verify_jwt_and_get_actor)"
            else:
                allowed_set_literal = ", ".join(f'"{a}"' for a in allowed_actors)
                security_check = (f'    if current_actor not in {{{allowed_set_literal}}}: '
                                   f'raise HTTPException(status_code=403, detail="Contrôle d\'accès : '
                                   f'Rôle parmi [{", ".join(allowed_actors)}] requis")')
                dependency_injection = "current_actor: str = Depends(verify_jwt_and_get_actor)"

            # Utilisé partout où dependency_injection doit s'insérer après
            # un ou plusieurs paramètres déjà présents dans la signature —
            # évite une virgule traînante invalide en syntaxe Python quand
            # dependency_injection est vide (route publique).
            dep_suffix = f", {dependency_injection}" if dependency_injection else ""

            if act_type == "Create":
                # AJOUT (post-v6, roadmap) : si l'entité a une relation entrante
                # (ex. "relation User hasMany Todo"), la colonne de clé étrangère
                # correspondante (ex. "user_id") est désormais réellement peuplée
                # à la création, à partir de l'identité JWT de l'appelant.
                # CORRECTIF DE GAP PRÉ-EXISTANT : cette colonne était déjà générée
                # dans schema.sql depuis les toutes premières versions, mais
                # jamais incluse dans la requête INSERT — elle restait NULL pour
                # tout enregistrement créé, rendant les relations inertes au
                # runtime malgré leur présence dans le schéma.
                owner_info = self._get_incoming_relation(base_target)
                # AJOUT (roadmap, écosystème de capacités -- brique 3,
                # généralisée en brique 4) : si cette relation entrante est la
                # cible d'une règle 'decrements'/'increments' (ex. "je
                # signale CE membre" ou "j'apprécie CE post"), ce n'est pas un
                # motif "propriétaire = appelant courant" -- le client fournit
                # explicitement la cible dans le corps de la requête (voir la
                # génération du schéma Pydantic ci-dessus), donc on ne tente
                # PAS de la peupler automatiquement depuis current_user_id.
                reputation_rules_here = self.reputation_rules_by_trigger.get(base_target, [])
                is_reputation_fk = owner_info and any(
                    r["target_entity"] == owner_info["source"] for r in reputation_rules_here
                )
                # Une route publique n'a par définition aucune identité
                # appelante fiable — on ne tente pas d'y rattacher une clé
                # étrangère "propriétaire" dans ce cas (la colonne reste NULL).
                populate_owner = owner_info and not is_public and not is_reputation_fk
                # AJOUT (roadmap, écosystème de capacités -- suite de la
                # brique 1) : un champ 'generated' est peuplé depuis le
                # pseudonyme anonyme du compte courant (déjà porté par le
                # JWT depuis /login), jamais depuis le corps de requête --
                # incompatible avec 'public' (validé par ast_validator.py),
                # donc l'appelant est nécessairement authentifié ici.
                generated_here = self.generated_fields_by_entity.get(base_target, [])
                create_deps = dependency_injection
                if populate_owner:
                    create_deps += ", current_user_id: int = Depends(get_current_user_id)" if create_deps else "current_user_id: int = Depends(get_current_user_id)"
                if generated_here:
                    create_deps += ", current_anon_handle: str = Depends(get_current_anon_handle)" if create_deps else "current_anon_handle: str = Depends(get_current_anon_handle)"
                create_deps_suffix = f", {create_deps}" if create_deps else ""

                api_lines.append(f"@app.post('/{base_target.lower()}', tags=['{tag}'])")
                api_lines.append(f"async def create_{base_target.lower()}(data: {base_target}Schema{create_deps_suffix}):")
                api_lines.append(security_check)
                api_lines.append("    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()")
                fields = list(self.entities[base_target].keys())
                insert_columns = list(fields)
                value_exprs = [("current_anon_handle" if f in generated_here else f"data.{f}") for f in fields]
                if populate_owner:
                    insert_columns.append(owner_info["fk_column"])
                    value_exprs.append("current_user_id")
                elif is_reputation_fk:
                    insert_columns.append(owner_info["fk_column"])
                    value_exprs.append(f"data.{owner_info['fk_column']}")
                columns = ", ".join(f'"{c}"' for c in insert_columns)
                placeholders = ", ".join(["?"] * len(insert_columns))
                api_lines.append(f"    query = 'INSERT INTO \"{base_target.lower()}\" ({columns}) VALUES ({placeholders})'")
                values_list = ", ".join(value_exprs)
                # CORRECTIF (bêta, intégrité transactionnelle) : l'insertion et
                # les effets 'increments'/'decrements' liés sont exécutés dans
                # UNE SEULE transaction, avec un unique commit à la fin et un
                # rollback en cas d'erreur. Avant, un commit intermédiaire après
                # l'INSERT puis un commit séparé par effet pouvaient laisser un
                # état partiel si le processus s'arrêtait entre les deux (ligne
                # créée mais compteur non mis à jour, ou l'inverse). Une cible
                # d'effet inexistante ne lève toujours pas d'erreur (UPDATE sans
                # ligne correspondante) — elle ne fait simplement rien.
                api_lines.append("    try:")
                api_lines.append(f"        cursor.execute(query, ({values_list},))")
                api_lines.append("        row_id = cursor.lastrowid")
                for rule in reputation_rules_here:
                    target_table = rule["target_entity"].lower()
                    target_field = rule["target_field"]
                    amount = rule["amount"]
                    sql_op = "-" if rule["direction"] == "decrements" else "+"
                    fk_value_expr = f"data.{owner_info['fk_column']}"
                    api_lines.append(
                        f"        cursor.execute('UPDATE \"{target_table}\" SET \"{target_field}\" = \"{target_field}\" {sql_op} ? "
                        f"WHERE id = ?', ({amount}, {fk_value_expr}))"
                    )
                api_lines.append("        conn.commit()")
                api_lines.append("    except Exception:")
                api_lines.append("        conn.rollback(); conn.close(); raise")
                api_lines.append("    conn.close()")
                api_lines.append(f"    return {{'status': 'success', 'id': row_id}}")
                api_lines.append("")
                
            elif act_type == "Read":
                # AJOUT (roadmap point 3, complété) : route de liste, en plus
                # de la lecture par ID déjà existante — jusqu'ici il n'existait
                # aucun moyen d'énumérer les enregistrements d'une entité sans
                # déjà connaître leurs identifiants un par un.
                # AJOUT (roadmap, pagination) : 'limit'/'offset' en paramètres
                # de requête (défaut 50, plafonné à 200), plus le nombre total
                # d'enregistrements — sans ça, une table volumineuse renverrait
                # tout d'un coup, sans borne.
                # CORRECTIF (roadmap, front visuel) : les lignes sont désormais
                # renvoyées comme des objets nommés {colonne: valeur} plutôt
                # que des tableaux positionnels bruts — un front (ou tout
                # client) n'a plus besoin de connaître l'ordre exact des
                # colonnes SQL pour afficher les données correctement.
                columns = self._get_row_column_names(base_target)
                columns_literal = ", ".join(f'"{c}"' for c in columns)
                # AJOUT (roadmap, écosystème de capacités -- brique 2) :
                # champs masqués (règle 'hidden') retirés de la réponse,
                # après construction du dict nommé mais avant de le renvoyer
                # -- jamais retirés de la base, jamais visibles par personne
                # via cette route, quel que soit qui l'appelle (contrairement
                # à 'restrictedTo', qui autorise un acteur précis).
                masked = self.hidden_fields_by_entity.get(base_target, [])
                mask_literal = ", ".join(f"'{f}'" for f in masked)
                # AJOUT (roadmap, écosystème de capacités -- brique 5) :
                # champs 'categorized' remplacés par leur libellé de
                # catégorie, dans la même passe que le masquage ci-dessus —
                # un seul parcours par ligne pour les deux transformations.
                categorized_here = self.categorized_fields_by_entity.get(base_target, [])
                # AJOUT (roadmap, brique "accès à deux parties") : si une
                # règle 'accessibleBy' cible Read, la liste ne renvoie que
                # les enregistrements dont l'appelant est l'une des parties
                # (WHERE col1 = ? OR col2 = ? ...), et la lecture par ID
                # vérifie l'appartenance avant de répondre. Comme pour
                # 'ownedBy', 'public' l'emporte si les deux sont déclarés
                # (pas d'identité appelante sur une route publique).
                read_parties = self.access_parties.get(f"{base_target}.Read")
                apply_read_parties = bool(read_parties) and not is_public
                read_dep_suffix = dep_suffix
                parties_where = parties_params = ""
                if apply_read_parties:
                    read_dep_suffix += ", current_user_id: int = Depends(get_current_user_id)"
                    parties_where = " OR ".join(f'\"{c}\" = ?' for c in read_parties)
                    parties_params = ", ".join(["current_user_id"] * len(read_parties))
                list_params = f"limit: int = 50, offset: int = 0{read_dep_suffix}"
                api_lines.append(f"@app.get('/{base_target.lower()}', tags=['{tag}'])")
                api_lines.append(f"async def list_{base_target.lower()}({list_params}):")
                api_lines.append(security_check)
                api_lines.append("    limit = max(1, min(limit, 200))")
                api_lines.append("    offset = max(0, offset)")
                api_lines.append("    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()")
                if apply_read_parties:
                    api_lines.append(f"    cursor.execute('SELECT COUNT(*) FROM \"{base_target.lower()}\" WHERE {parties_where}', ({parties_params},))")
                else:
                    api_lines.append(f"    cursor.execute('SELECT COUNT(*) FROM \"{base_target.lower()}\"')")
                api_lines.append("    total = cursor.fetchone()[0]")
                if apply_read_parties:
                    api_lines.append(f"    cursor.execute('SELECT * FROM \"{base_target.lower()}\" WHERE {parties_where} LIMIT ? OFFSET ?', ({parties_params}, limit, offset))")
                else:
                    api_lines.append(f"    cursor.execute('SELECT * FROM \"{base_target.lower()}\" LIMIT ? OFFSET ?', (limit, offset))")
                api_lines.append("    rows = cursor.fetchall()")
                api_lines.append("    _columns = [d[0] for d in cursor.description]  # ordre réel en base (robuste aux migrations)")
                api_lines.append("    conn.close()")
                api_lines.append("    named_rows = [dict(zip(_columns, row)) for row in rows]")
                row_loop_lines = []
                if masked:
                    row_loop_lines.append(f"        for _f in [{mask_literal}]: _r.pop(_f, None)")
                for cf in categorized_here:
                    row_loop_lines.extend(self._emit_categorization_lines(cf, "_r", "        "))
                if row_loop_lines:
                    api_lines.append("    for _r in named_rows:")
                    api_lines.extend(row_loop_lines)
                api_lines.append("    return {'status': 'success', 'total': total, 'limit': limit, 'offset': offset, 'data': named_rows}")
                api_lines.append("")

                api_lines.append(f"@app.get('/{base_target.lower()}/{{id}}', tags=['{tag}'])")
                api_lines.append(f"async def read_{base_target.lower()}(id: int{read_dep_suffix}):")
                api_lines.append(security_check)
                api_lines.append("    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()")
                api_lines.append(f"    cursor.execute('SELECT * FROM \"{base_target.lower()}\" WHERE id = ?', (id,))")
                api_lines.append("    row = cursor.fetchone()")
                api_lines.append("    _columns = [d[0] for d in cursor.description]  # ordre réel en base (robuste aux migrations)")
                api_lines.append("    conn.close()")
                api_lines.append("    if not row: raise HTTPException(status_code=404, detail='Enregistrement introuvable')")
                api_lines.append("    named_row = dict(zip(_columns, row))")
                if apply_read_parties:
                    # La vérification se fait AVANT le masquage 'hidden' :
                    # une colonne de partie peut légitimement être masquée
                    # en lecture tout en servant au contrôle d'accès.
                    parties_tuple = ", ".join(f"named_row.get('{c}')" for c in read_parties)
                    api_lines.append(f"    if current_user_id not in ({parties_tuple}):")
                    api_lines.append("        raise HTTPException(status_code=403, detail=\"Contrôle d'accès : seules les parties de la ressource peuvent la consulter\")")
                if masked:
                    api_lines.append(f"    for _f in [{mask_literal}]: named_row.pop(_f, None)")
                for cf in categorized_here:
                    api_lines.extend(self._emit_categorization_lines(cf, "named_row", "    "))
                api_lines.append("    return {'status': 'success', 'data': named_row}")
                api_lines.append("")
                
            elif act_type == "Update":
                # AJOUT (post-v6, roadmap) : si une règle 'ownedBy' cible cette
                # action, un contrôle supplémentaire vérifie que l'acteur courant
                # est bien le propriétaire de l'enregistrement, en plus du
                # contrôle de rôle habituel.
                owner_entity = self.ownership.get(f"{base_target}.Update")
                # 'ownedBy' suppose une identité appelante (current_actor) —
                # incompatible avec une route 'public', qui n'en a aucune.
                # Si les deux sont déclarées sur la même action, 'public'
                # l'emporte : la route reste ouverte, sans contrôle de
                # propriété (voir docs/design_decisions.md).
                apply_ownership = owner_entity and not is_public
                # AJOUT (roadmap, brique "accès à deux parties") : même
                # principe que 'ownedBy' mais l'appelant doit être l'UNE des
                # colonnes-parties listées. Contrairement à 'ownedBy', le
                # contrôle s'applique à tous les acteurs de la route (les
                # parties sont des colonnes de données, pas des rôles) —
                # combiner avec 'sharedBy' pour un rôle superviseur n'est
                # pas couvert par cette première version (documenté).
                update_parties = self.access_parties.get(f"{base_target}.Update")
                apply_update_parties = bool(update_parties) and not is_public
                update_deps = dependency_injection
                ownership_check_lines = []
                if apply_update_parties:
                    update_deps += ", current_user_id: int = Depends(get_current_user_id)" if update_deps else "current_user_id: int = Depends(get_current_user_id)"
                    cols_literal = ", ".join(f'\"{c}\"' for c in update_parties)
                    ownership_check_lines = [
                        "    _p_conn = sqlite3.connect(DB_FILE); _p_cur = _p_conn.cursor()",
                        f"    _p_cur.execute('SELECT {cols_literal} FROM \"{base_target.lower()}\" WHERE id = ?', (id,))",
                        "    _p_row = _p_cur.fetchone(); _p_conn.close()",
                        "    if not _p_row: raise HTTPException(status_code=404, detail='Enregistrement introuvable')",
                        "    if current_user_id not in _p_row: raise HTTPException(status_code=403, "
                        "detail=\"Contrôle d'accès : seules les parties de la ressource peuvent exécuter cette action\")",
                    ]
                elif apply_ownership:
                    fk_col = f"{owner_entity.lower()}_id"
                    update_deps += ", current_user_id: int = Depends(get_current_user_id)" if update_deps else "current_user_id: int = Depends(get_current_user_id)"
                    # CORRECTIF (roadmap, combinaison ownedBy + sharedBy) : si
                    # cette route est partagée par plusieurs acteurs (ex. un
                    # 'Agent' qui gère tous les tickets, en plus du 'Customer'
                    # propriétaire), le contrôle de propriété ne doit s'appliquer
                    # qu'à l'acteur explicitement désigné comme propriétaire par
                    # la règle 'ownedBy' — pas aux autres acteurs qui partagent
                    # la route par ailleurs via leur propre rôle. Sans cette
                    # condition, un acteur légitimement privilégié (Agent) se
                    # retrouverait bloqué à tort, puisqu'il ne "possède" jamais
                    # la ressource au sens de la relation hasMany/belongsTo.
                    ownership_check_lines = [
                        f"    if current_actor == \"{owner_entity}\":",
                        "        _owner_conn = sqlite3.connect(DB_FILE); _owner_cur = _owner_conn.cursor()",
                        f"        _owner_cur.execute('SELECT \"{fk_col}\" FROM \"{base_target.lower()}\" WHERE id = ?', (id,))",
                        "        _owner_row = _owner_cur.fetchone(); _owner_conn.close()",
                        "        if not _owner_row: raise HTTPException(status_code=404, detail='Enregistrement introuvable')",
                        "        if _owner_row[0] != current_user_id: raise HTTPException(status_code=403, "
                        "detail=\"Contrôle d'accès : seul le propriétaire de la ressource peut exécuter cette action\")",
                    ]

                update_deps_suffix = f", {update_deps}" if update_deps else ""
                api_lines.append(f"@app.put('/{base_target.lower()}/{{id}}', tags=['{tag}'])")
                api_lines.append(f"async def update_{base_target.lower()}(id: int, data: {base_target}Schema{update_deps_suffix}):")
                api_lines.append(security_check)
                api_lines.extend(ownership_check_lines)
                api_lines.append("    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()")
                fields = list(self.entities[base_target].keys())
                update_stmt = ", ".join([f'"{f}" = ?' for f in fields])
                api_lines.append(f"    query = 'UPDATE \"{base_target.lower()}\" SET {update_stmt} WHERE id = ?'")
                values_list = ", ".join([f"data.{f}" for f in fields])
                api_lines.append(f"    cursor.execute(query, ({values_list}, id))")
                api_lines.append("    conn.commit(); conn.close()")
                api_lines.append(f"    return {{'status': 'success', 'id': id}}")
                api_lines.append("")

            elif act_type == "Delete":
                owner_entity = self.ownership.get(f"{base_target}.Delete")
                apply_ownership = owner_entity and not is_public
                # AJOUT (roadmap, brique "accès à deux parties") — voir le
                # commentaire équivalent sur la route Update.
                delete_parties = self.access_parties.get(f"{base_target}.Delete")
                apply_delete_parties = bool(delete_parties) and not is_public
                delete_deps = dependency_injection
                ownership_check_lines = []
                if apply_delete_parties:
                    delete_deps += ", current_user_id: int = Depends(get_current_user_id)" if delete_deps else "current_user_id: int = Depends(get_current_user_id)"
                    cols_literal = ", ".join(f'\"{c}\"' for c in delete_parties)
                    ownership_check_lines = [
                        "    _p_conn = sqlite3.connect(DB_FILE); _p_cur = _p_conn.cursor()",
                        f"    _p_cur.execute('SELECT {cols_literal} FROM \"{base_target.lower()}\" WHERE id = ?', (id,))",
                        "    _p_row = _p_cur.fetchone(); _p_conn.close()",
                        "    if not _p_row: raise HTTPException(status_code=404, detail='Enregistrement introuvable')",
                        "    if current_user_id not in _p_row: raise HTTPException(status_code=403, "
                        "detail=\"Contrôle d'accès : seules les parties de la ressource peuvent exécuter cette action\")",
                    ]
                elif apply_ownership:
                    fk_col = f"{owner_entity.lower()}_id"
                    delete_deps += ", current_user_id: int = Depends(get_current_user_id)" if delete_deps else "current_user_id: int = Depends(get_current_user_id)"
                    # Voir le commentaire équivalent dans le bloc "Update" ci-dessus :
                    # le contrôle de propriété ne s'applique qu'à l'acteur
                    # explicitement désigné comme propriétaire par 'ownedBy'.
                    ownership_check_lines = [
                        f"    if current_actor == \"{owner_entity}\":",
                        "        _owner_conn = sqlite3.connect(DB_FILE); _owner_cur = _owner_conn.cursor()",
                        f"        _owner_cur.execute('SELECT \"{fk_col}\" FROM \"{base_target.lower()}\" WHERE id = ?', (id,))",
                        "        _owner_row = _owner_cur.fetchone(); _owner_conn.close()",
                        "        if not _owner_row: raise HTTPException(status_code=404, detail='Enregistrement introuvable')",
                        "        if _owner_row[0] != current_user_id: raise HTTPException(status_code=403, "
                        "detail=\"Contrôle d'accès : seul le propriétaire de la ressource peut exécuter cette action\")",
                    ]

                delete_deps_suffix = f", {delete_deps}" if delete_deps else ""
                api_lines.append(f"@app.delete('/{base_target.lower()}/{{id}}', tags=['{tag}'])")
                api_lines.append(f"async def delete_{base_target.lower()}(id: int{delete_deps_suffix}):")
                api_lines.append(security_check)
                api_lines.extend(ownership_check_lines)
                api_lines.append("    conn = sqlite3.connect(DB_FILE); cursor = conn.cursor()")
                api_lines.append(f"    cursor.execute('DELETE FROM \"{base_target.lower()}\" WHERE id = ?', (id,))")
                api_lines.append("    conn.commit(); conn.close()")
                api_lines.append(f"    return {{'status': 'success', 'id': id}}")
                api_lines.append("")
                
            elif act_type == "Execute":
                api_lines.append(f"@app.post('/workflow/{tag.lower()}/{target.lower()}', tags=['{tag}'])")
                api_lines.append(f"async def execute_{target.lower()}(payload: {target}InputSchema, {dependency_injection}):")
                api_lines.append(security_check)
                api_lines.append(f"    result = sandbox_ai.{target}(payload.dict())")
                api_lines.append("    return {'status': 'executed', 'sandbox_result': result}")
                api_lines.append("")
                    
        return "\n".join(api_lines)

    def _select_theme(self, seed=None):
        """AJOUT (roadmap, identité visuelle) : choisit un système visuel
        complet (palette, typographies, rayon de bordure, traitement des
        cartes) parmi 5 propositions distinctes et volontairement écartées
        des trois looks par défaut que produit une IA sans direction (fond
        crème + accent terracotta, fond quasi-noir + accent acide unique,
        colonnes façon journal à filets fins). Le choix est motivé par le
        vocabulaire du domaine (noms d'entités/attributs/app) quand un signal
        existe ; sinon il est réparti de façon stable (par hachage du nom de
        l'app) entre les 5 systèmes, pour que deux apps génériques différentes
        ne se ressemblent pas non plus."""
        themes = {
            "editorial": {
                "keywords": {"post", "article", "blog", "comment", "story", "author", "publish"},
                "bg": "#F3EFE1", "surface": "#FFFFFF", "ink": "#241F16",
                "accent": "#2F5D50", "accent2": "#B23A48",
                "font_display": "'Fraunces', Georgia, serif",
                "font_body": "'Inter', -apple-system, sans-serif",
                "font_mono": "'IBM Plex Mono', monospace",
                "google_fonts": "Fraunces:opsz,wght@9..144,400;9..144,600&family=Inter:wght@400;500;600",
                "radius": "4px", "card_style": "editorial",
            },
            "market": {
                "keywords": {"product", "order", "price", "cart", "shop", "invoice", "money",
                              "stock", "customer", "payment", "checkout"},
                "bg": "#EFEDE4", "surface": "#FFFFFF", "ink": "#1B2420",
                "accent": "#0B6E4F", "accent2": "#C98A00",
                "font_display": "'Barlow Condensed', sans-serif",
                "font_body": "'Work Sans', -apple-system, sans-serif",
                "font_mono": "'IBM Plex Mono', monospace",
                "google_fonts": "Barlow+Condensed:wght@600;700&family=Work+Sans:wght@400;500",
                "radius": "2px", "card_style": "market",
            },
            "console": {
                "keywords": {"todo", "task", "ticket", "issue", "workflow", "project", "bug", "status"},
                "bg": "#161A1E", "surface": "#20262C", "ink": "#E7E4DC",
                "accent": "#5B8DEF", "accent2": "#3FB68B",
                "font_display": "'IBM Plex Mono', monospace",
                "font_body": "'IBM Plex Sans', -apple-system, sans-serif",
                "font_mono": "'IBM Plex Mono', monospace",
                "google_fonts": "IBM+Plex+Mono:wght@500;600&family=IBM+Plex+Sans:wght@400;500",
                "radius": "10px", "card_style": "console",
            },
            "civic": {
                "keywords": {"reservation", "booking", "event", "member", "social", "friend",
                              "profile", "community", "guest", "appointment", "slot",
                              "professional", "schedule"},
                "bg": "#F1ECE4", "surface": "#FFFFFF", "ink": "#2B2118",
                "accent": "#3D5A80", "accent2": "#C9A227",
                "font_display": "'Newsreader', Georgia, serif",
                "font_body": "'Manrope', -apple-system, sans-serif",
                "font_mono": "'IBM Plex Mono', monospace",
                "google_fonts": "Newsreader:ital,wght@1,500;0,600&family=Manrope:wght@400;500;600",
                "radius": "18px", "card_style": "civic",
            },
            "ledger": {
                "keywords": set(),
                "bg": "#EAE6DC", "surface": "#FFFFFF", "ink": "#1E1B16",
                "accent": "#1D3557", "accent2": "#588157",
                "font_display": "'Libre Caslon Text', Georgia, serif",
                "font_body": "'IBM Plex Sans', -apple-system, sans-serif",
                "font_mono": "'IBM Plex Mono', monospace",
                "google_fonts": "Libre+Caslon+Text:wght@400;700&family=IBM+Plex+Sans:wght@400;500",
                "radius": "6px", "card_style": "ledger",
            },
        }

        # AJOUT (roadmap, contrôle du rendu visuel) : un bloc 'ui' peut forcer
        # explicitement le thème de toute l'application (le thème reste une
        # identité unique par app, partagée par toutes les entités, pas un
        # réglage par entité) — la première surcharge valide trouvée l'emporte
        # sur la sélection automatique par mots-clés.
        theme_name, theme = None, None
        for override in self.ui_overrides.values():
            requested_theme = override.get("theme")
            if requested_theme and requested_theme in themes:
                theme_name, theme = requested_theme, dict(themes[requested_theme])
                break

        if theme_name is None:
            vocabulary = (self.app_name + " " + " ".join(self.entities.keys())).lower()
            for entity_attrs in self.entities.values():
                vocabulary += " " + " ".join(entity_attrs.keys()).lower()

            scores = {name: sum(1 for kw in t["keywords"] if kw in vocabulary) for name, t in themes.items()}
            best_score = max(scores.values())

            if best_score > 0:
                candidates = sorted([n for n, s in scores.items() if s == best_score])
            else:
                candidates = sorted(themes.keys())

            hash_source = self.app_name + (":" + seed if seed else "")
            pick_index = int(hashlib.sha256(hash_source.encode()).hexdigest(), 16) % len(candidates)
            theme_name = candidates[pick_index]
            theme = dict(themes[theme_name])

        # AJOUT (roadmap, unicité visuelle par projet) : le choix ci-dessus
        # ne dépend QUE du domaine (vocabulaire de l'app) — deux projets de
        # même domaine (deux todo-lists, par exemple) obtiennent donc le
        # même thème de base à chaque fois, par construction. La graine
        # aléatoire propre au projet (voir _load_or_create_theme_seed) sert
        # ici à appliquer une variation fine SUR ce thème (teinte des
        # couleurs d'accent, rayon des bordures) sans jamais changer le
        # thème lui-même : deux todo-lists restent bien reconnaissables
        # comme telles (même palette de base, mêmes polices), mais cessent
        # d'être des pixels identiques.
        if seed:
            variation_hash = hashlib.sha256(f"{self.app_name}:{seed}".encode()).hexdigest()
            hue_shift_accent = (int(variation_hash[0:4], 16) % 41) - 20     # -20..+20 degrés
            hue_shift_accent2 = (int(variation_hash[4:8], 16) % 41) - 20
            radius_factor = 0.8 + (int(variation_hash[8:10], 16) % 41) / 100.0  # ~0.8x..1.2x
            theme["accent"] = self._shift_hue(theme["accent"], hue_shift_accent)
            theme["accent2"] = self._shift_hue(theme["accent2"], hue_shift_accent2)
            base_radius_px = float(theme["radius"].replace("px", ""))
            theme["radius"] = f"{round(base_radius_px * radius_factor, 1)}px"

        return theme_name, theme

    @staticmethod
    def _shift_hue(hex_color, degrees):
        """AJOUT (roadmap, unicité visuelle par projet) : fait pivoter la
        teinte (HSL) d'une couleur hexadécimale d'un nombre de degrés donné,
        en conservant sa luminosité et sa saturation d'origine -- donc son
        niveau de contraste avec le fond/le texte, ce qui est important pour
        la lisibilité. N'agit que sur les couleurs d'accent, jamais sur
        bg/surface/ink, pour ne pas risquer de dégrader le contraste texte."""
        hex_color = hex_color.lstrip("#")
        r, g, b = (int(hex_color[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
        h, l, s = colorsys.rgb_to_hls(r, g, b)
        h = (h + degrees / 360.0) % 1.0
        r, g, b = colorsys.hls_to_rgb(h, l, s)
        return "#{:02X}{:02X}{:02X}".format(round(r * 255), round(g * 255), round(b * 255))

    def _load_or_create_theme_seed(self):
        """AJOUT (roadmap, unicité visuelle par projet) : génère, à la toute
        première compilation d'un projet, une graine aléatoire de 16 octets
        conservée dans '.monl_theme_seed' (ignorée via .gitignore,
        jamais commitée -- même logique que '.jwt_secret'). Recompiler la
        spec NE régénère PAS la graine : le style visuel du projet reste
        stable dans le temps ; il faut supprimer le fichier à la main pour
        en tirer un nouveau look."""
        # La graine appartient au projet compilé : elle suit --output.
        seed_path = os.path.join(self.output_dir, ".monl_theme_seed")
        if not os.path.exists(seed_path):
            new_seed = secrets.token_hex(16)
            with open(seed_path, "w", encoding="utf-8") as f:
                f.write(new_seed)
            print("🎨 Nouvelle graine de variation visuelle générée et stockée dans '.monl_theme_seed'.")
            return new_seed
        with open(seed_path, "r", encoding="utf-8") as f:
            return f.read().strip()

    def _compute_route_map(self):
        """Regroupe les actions par (type, cible) avec la liste des acteurs
        autorisés et le 'tag' (nom du premier workflow qui déclare l'action)
        -- extrait de _generate_secure_fastapi pour être réutilisé aussi par
        _compute_actor_capabilities (le tableau de bord post-connexion a
        besoin du même 'tag' que la vraie route pour appeler les fonctions
        'custom' au bon endroit). Une seule source de vérité : si cette
        logique de regroupement change un jour, les deux consommateurs
        restent forcément synchronisés."""
        route_map = {}
        for wf in self.workflows:
            wf_name = wf["name"]
            required_actor = wf["actor"]
            for action in wf["actions"]:
                act_type = action["type"]
                target = action["target"]
                base_target = target.split(".")[0] if "." in target else target
                route_key = (act_type, base_target if act_type != "Execute" else target)
                if route_key not in route_map:
                    route_map[route_key] = {"actors": set(), "tags": [], "target": target, "base_target": base_target}
                route_map[route_key]["actors"].add(required_actor)
                if wf_name not in route_map[route_key]["tags"]:
                    route_map[route_key]["tags"].append(wf_name)
        return route_map

    def _generate_ai_sandbox(self):
        """Génère les coquilles vides des blocs 'custom' — logique métier
        à écrire à la main dans ce module (aucune IA ne les remplit)."""
        sb_lines = ["# BLOCS 'custom' — logique métier à compléter à la main (déterministe)\n"]
        for func in self.custom_functions:
            name = func["name"]
            desc = func.get("description", "Logique métier custom.").strip()
            sb_lines.append(f"def {name}(context: dict) -> dict:\n    \"\"\"\n    Objectif : {desc}\n    \"\"\"\n    # TODO:\n    return {{'message': 'Coquille vide déterministe pour {name}'}}\n")
        return "\n".join(sb_lines)

if __name__ == "__main__":
    sample_path = os.path.join(os.path.dirname(__file__), "../exemples/01_portfolio.ml")
    try:
        raw_json = parse_monl_file(sample_path)
        ast_manager = MonlAST(raw_json)
        normalized_ast = ast_manager.validate_and_audit()
        generator = MonlSecureGenerator(normalized_ast)
        generator.generate_all()
    except Exception as e:
        print(f"❌ Échec : {e}")
